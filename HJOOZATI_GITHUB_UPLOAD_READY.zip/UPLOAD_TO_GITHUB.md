# Upload HJOOZATI source to GitHub

This package is prepared for the repository root (not as a nested `HJOOZATI/` folder).

## Upload steps
1. Open your target repository: `https://github.com/sexox/HJOOZATI-REBUILDD`.
2. Extract this ZIP on your device.
3. Upload the **contents** of the extracted folder to the repository root. Keep hidden folders, especially `.github/workflows/`.
4. Commit the upload to the `main` branch.
5. Open the repository's **Actions** tab and select **Android Build** if it does not start automatically.
6. Wait for the workflow to finish. On success, open the run, find **Artifacts**, and download `hjoozati-debug-apk`. Extract that artifact ZIP to get `app-debug.apk`.

## Important
- Do not upload the outer ZIP as a single file if you want GitHub Actions to build it. The workflow must exist at `.github/workflows/android-build.yml` in the repository root.
- Do not upload these files into a subfolder; `app/`, `build.gradle.kts`, and `settings.gradle.kts` must be at the repository root.
- The original `HJOOZATI` repository is not the target. Use `HJOOZATI-REBUILDD`.
- A successful workflow build is the first APK build verification; install and test the APK on your Android device before production use.
