package com.hjoozati.app.data

/** Validates and calculates the booking cash ledger. All amounts use the app's smallest currency unit. */
object BookingFinance {
    enum class EntryKind { PAYMENT, REFUND }

    data class Summary(
        val total: Long,
        val collected: Long,
        val outstanding: Long,
        val refundDue: Long,
        val state: BookingRules.PaymentState
    )

    fun validateEntry(kind: EntryKind, amount: Long, currentNetPaid: Long, bookingTotal: Long) {
        require(bookingTotal >= 0L) { "Booking total cannot be negative" }
        require(amount > 0L) { "Amount must be greater than zero" }
        when (kind) {
            EntryKind.PAYMENT -> {
                require(currentNetPaid >= 0L) { "Collected balance cannot be negative before a payment" }
                val next = Math.addExact(currentNetPaid, amount)
                require(next <= bookingTotal) { "Payment exceeds the remaining booking balance" }
            }
            EntryKind.REFUND -> {
                require(currentNetPaid >= 0L && amount <= currentNetPaid) { "Refund exceeds the amount collected" }
            }
        }
    }

    fun summarize(total: Long, netPaid: Long): Summary {
        require(total >= 0L) { "Booking total cannot be negative" }
        val state = BookingRules.paymentState(total, netPaid)
        return Summary(
            total = total,
            collected = netPaid.coerceAtLeast(0L),
            outstanding = (total - netPaid).coerceAtLeast(0L),
            refundDue = (-netPaid).coerceAtLeast(0L),
            state = state
        )
    }

    fun applyNet(currentNetPaid: Long, kind: EntryKind, amount: Long): Long {
        require(amount > 0L) { "Amount must be greater than zero" }
        return when (kind) {
            EntryKind.PAYMENT -> Math.addExact(currentNetPaid, amount)
            EntryKind.REFUND -> Math.subtractExact(currentNetPaid, amount)
        }
    }
}
