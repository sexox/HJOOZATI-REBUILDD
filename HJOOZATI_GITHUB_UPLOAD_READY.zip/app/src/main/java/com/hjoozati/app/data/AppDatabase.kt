package com.hjoozati.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Booking::class, Payment::class, Tournament::class, TournamentTeam::class,
        TournamentMatch::class, RecurringRule::class, AppSetting::class, ImportantEvent::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookingDao(): BookingDao
    abstract fun paymentDao(): PaymentDao
    abstract fun tournamentDao(): TournamentDao
    abstract fun recurringRuleDao(): RecurringRuleDao
    abstract fun appSettingDao(): AppSettingDao
    abstract fun importantEventDao(): ImportantEventDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, bookingId INTEGER NOT NULL, amount INTEGER NOT NULL, kind TEXT NOT NULL, method TEXT NOT NULL, note TEXT NOT NULL, paidAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_bookingId ON payments(bookingId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_payments_paidAt ON payments(paidAt)")
                db.execSQL("INSERT INTO payments (bookingId, amount, kind, method, note, paidAt) SELECT id, paid, 'PAYMENT', 'LEGACY', 'Migrated from previous booking balance', createdAt FROM bookings WHERE paid > 0")
                db.execSQL("CREATE TABLE IF NOT EXISTS tournaments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, format TEXT NOT NULL, startDate TEXT NOT NULL, endDate TEXT NOT NULL, status TEXT NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tournaments_startDate ON tournaments(startDate)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tournaments_status ON tournaments(status)")
                db.execSQL("CREATE TABLE IF NOT EXISTS tournament_teams (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, tournamentId INTEGER NOT NULL, name TEXT NOT NULL, groupName TEXT NOT NULL, played INTEGER NOT NULL, won INTEGER NOT NULL, drawn INTEGER NOT NULL, lost INTEGER NOT NULL, goalsFor INTEGER NOT NULL, goalsAgainst INTEGER NOT NULL, points INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tournament_teams_tournamentId ON tournament_teams(tournamentId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS tournament_matches (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, tournamentId INTEGER NOT NULL, homeTeamId INTEGER NOT NULL, awayTeamId INTEGER NOT NULL, matchDate TEXT NOT NULL, startTime TEXT NOT NULL, homeScore INTEGER, awayScore INTEGER, roundName TEXT NOT NULL, status TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tournament_matches_tournamentId ON tournament_matches(tournamentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tournament_matches_matchDate ON tournament_matches(matchDate)")
                db.execSQL("CREATE TABLE IF NOT EXISTS recurring_rules (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, bookingId INTEGER NOT NULL, frequency TEXT NOT NULL, repeatInterval INTEGER NOT NULL, weekdaysCsv TEXT NOT NULL, untilDate TEXT NOT NULL, occurrenceCount INTEGER NOT NULL, active INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recurring_rules_bookingId ON recurring_rules(bookingId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_recurring_rules_active ON recurring_rules(active)")
                db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (settingKey TEXT NOT NULL PRIMARY KEY, value TEXT NOT NULL)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS important_events (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, title TEXT NOT NULL, date TEXT NOT NULL, time TEXT NOT NULL, notes TEXT NOT NULL, createdAt INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_important_events_date ON important_events(date)")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "hjoozati.db"
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { INSTANCE = it }
        }
    }
}
