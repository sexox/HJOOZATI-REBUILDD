package com.hjoozati.app.data

import androidx.room.withTransaction
import org.json.JSONArray
import org.json.JSONObject

/** Versioned, offline backup. Restore validates the complete payload before replacing local data. */
class BackupManager(private val db: AppDatabase) {
    suspend fun exportJson(): String {
        val root = JSONObject().put("format", "HJOOZATI_BACKUP").put("version", 2).put("createdAt", System.currentTimeMillis())
        root.put("bookings", JSONArray().apply { db.bookingDao().getAllSnapshot().forEach { b -> put(JSONObject()
            .put("id",b.id).put("customerName",b.customerName).put("phone",b.phone).put("date",b.date)
            .put("startTime",b.startTime).put("endTime",b.endTime).put("startMinutes",b.startMinutes).put("endMinutes",b.endMinutes)
            .put("teamOne",b.teamOne).put("teamTwo",b.teamTwo).put("pricePerTeam",b.pricePerTeam).put("paid",b.paid)
            .put("matchType",b.matchType).put("tournamentName",b.tournamentName).put("tournamentStage",b.tournamentStage)
            .put("notes",b.notes).put("status",b.status).put("createdAt",b.createdAt)) } })
        root.put("payments", JSONArray().apply { db.paymentDao().getAllSnapshot().forEach { p -> put(JSONObject().put("id",p.id).put("bookingId",p.bookingId).put("amount",p.amount).put("kind",p.kind).put("method",p.method).put("note",p.note).put("paidAt",p.paidAt)) } })
        root.put("tournaments", JSONArray().apply { db.tournamentDao().getAllSnapshot().forEach { t -> put(JSONObject().put("id",t.id).put("name",t.name).put("format",t.format).put("startDate",t.startDate).put("endDate",t.endDate).put("status",t.status).put("notes",t.notes).put("createdAt",t.createdAt)) } })
        root.put("teams", JSONArray().apply { db.tournamentDao().getAllTeamsSnapshot().forEach { t -> put(JSONObject().put("id",t.id).put("tournamentId",t.tournamentId).put("name",t.name).put("groupName",t.groupName).put("played",t.played).put("won",t.won).put("drawn",t.drawn).put("lost",t.lost).put("goalsFor",t.goalsFor).put("goalsAgainst",t.goalsAgainst).put("points",t.points)) } })
        root.put("matches", JSONArray().apply { db.tournamentDao().getAllMatchesSnapshot().forEach { m -> put(JSONObject().put("id",m.id).put("tournamentId",m.tournamentId).put("homeTeamId",m.homeTeamId).put("awayTeamId",m.awayTeamId).put("matchDate",m.matchDate).put("startTime",m.startTime).put("homeScore",m.homeScore ?: JSONObject.NULL).put("awayScore",m.awayScore ?: JSONObject.NULL).put("roundName",m.roundName).put("status",m.status)) } })
        root.put("recurringRules", JSONArray().apply { db.recurringRuleDao().getAllSnapshot().forEach { r -> put(JSONObject().put("id",r.id).put("bookingId",r.bookingId).put("frequency",r.frequency).put("repeatInterval",r.repeatInterval).put("weekdaysCsv",r.weekdaysCsv).put("untilDate",r.untilDate).put("occurrenceCount",r.occurrenceCount).put("active",r.active)) } })
        root.put("settings", JSONArray().apply { db.appSettingDao().getAllSnapshot().forEach { a -> put(JSONObject().put("settingKey",a.settingKey).put("value",a.value)) } })
        root.put("importantEvents", JSONArray().apply { db.importantEventDao().getAllSnapshot().forEach { e -> put(JSONObject().put("id",e.id).put("title",e.title).put("date",e.date).put("time",e.time).put("notes",e.notes).put("createdAt",e.createdAt)) } })
        return root.toString(2)
    }

    suspend fun restoreJson(json: String) {
        val root = JSONObject(json)
        require(root.getString("format") == "HJOOZATI_BACKUP") { "This is not a HJOOZATI backup" }
        require(root.getInt("version") in 1..2) { "Unsupported backup version" }
        val bookings = root.getJSONArray("bookings"); val payments = root.getJSONArray("payments")
        val tournaments = root.getJSONArray("tournaments"); val teams = root.getJSONArray("teams")
        val matches = root.getJSONArray("matches"); val rules = root.getJSONArray("recurringRules"); val settings = root.getJSONArray("settings"); val events = root.optJSONArray("importantEvents") ?: JSONArray()
        // Validate references and values before destructive replacement.
        val bookingRows = (0 until bookings.length()).map { bookings.getJSONObject(it) }
        val paymentRows = (0 until payments.length()).map { payments.getJSONObject(it) }
        val tournamentRows = (0 until tournaments.length()).map { tournaments.getJSONObject(it) }
        val teamRows = (0 until teams.length()).map { teams.getJSONObject(it) }
        val matchRows = (0 until matches.length()).map { matches.getJSONObject(it) }
        val ruleRows = (0 until rules.length()).map { rules.getJSONObject(it) }
        val eventRows = (0 until events.length()).map { events.getJSONObject(it) }
        fun uniquePositiveIds(rows: List<JSONObject>, label: String) {
            val ids = rows.map { it.getLong("id") }
            require(ids.all { it > 0L } && ids.distinct().size == ids.size) { "Invalid or duplicate $label IDs" }
        }
        uniquePositiveIds(bookingRows, "booking"); uniquePositiveIds(paymentRows, "payment")
        uniquePositiveIds(tournamentRows, "tournament"); uniquePositiveIds(teamRows, "team")
        uniquePositiveIds(matchRows, "match"); uniquePositiveIds(ruleRows, "recurrence")
        uniquePositiveIds(eventRows, "event")
        val bookingIds = bookingRows.map { it.getLong("id") }.toSet()
        val tournamentIds = tournamentRows.map { it.getLong("id") }.toSet()
        val teamTournament = teamRows.associate { it.getLong("id") to it.getLong("tournamentId") }
        val bookingTotals = mutableMapOf<Long, Long>()
        bookingRows.forEach { b ->
            val price = b.getLong("pricePerTeam")
            require(b.getString("customerName").isNotBlank() && price in 0..(Long.MAX_VALUE / 2))
            val start = java.time.LocalTime.parse(b.getString("startTime")); val end = java.time.LocalTime.parse(b.getString("endTime"))
            require(b.getInt("startMinutes") == start.hour * 60 + start.minute && b.getInt("endMinutes") == end.hour * 60 + end.minute && b.getInt("endMinutes") > b.getInt("startMinutes"))
            require(runCatching { java.time.LocalDate.parse(b.getString("date")) }.isSuccess)
            require(b.getLong("paid") in 0..(price * 2))
            bookingTotals[b.getLong("id")] = price * 2
        }
        val ledgerNet = mutableMapOf<Long, Long>()
        paymentRows.sortedWith(compareBy<JSONObject> { it.getLong("paidAt") }.thenBy { it.getLong("id") }).forEach { x ->
            val bookingId = x.getLong("bookingId")
            require(bookingId in bookingIds && x.getLong("amount") > 0L && x.getString("kind") in setOf("PAYMENT", "REFUND"))
            val current = ledgerNet[bookingId] ?: 0L
            val amount = x.getLong("amount")
            val next = when (x.getString("kind")) {
                "PAYMENT" -> Math.addExact(current, amount).also { require(it <= bookingTotals.getValue(bookingId)) { "Payment exceeds booking total" } }
                else -> { require(amount <= current) { "Refund exceeds prior collected payments" }; Math.subtractExact(current, amount) }
            }
            ledgerNet[bookingId] = next
        }
        bookingRows.forEach { b -> require((ledgerNet[b.getLong("id")] ?: 0L) == b.getLong("paid")) { "Payment ledger does not match booking balance" } }
        tournamentRows.forEach { t ->
            require(t.getString("name").isNotBlank() && t.getString("format") in setOf("KNOCKOUT", "LEAGUE", "GROUPS_KNOCKOUT"))
            val start = java.time.LocalDate.parse(t.getString("startDate")); val end = java.time.LocalDate.parse(t.getString("endDate")); require(!end.isBefore(start))
        }
        teamRows.forEach { t -> require(t.getLong("tournamentId") in tournamentIds && t.getString("name").isNotBlank()) }
        matchRows.forEach { x ->
            val tournamentId = x.getLong("tournamentId");
            require(tournamentId in tournamentIds && teamTournament[x.getLong("homeTeamId")] == tournamentId && teamTournament[x.getLong("awayTeamId")] == tournamentId && x.getLong("homeTeamId") != x.getLong("awayTeamId"))
            java.time.LocalDate.parse(x.getString("matchDate")); java.time.LocalTime.parse(x.getString("startTime"))
            require((x.isNull("homeScore") && x.isNull("awayScore")) || (!x.isNull("homeScore") && !x.isNull("awayScore") && x.getInt("homeScore") >= 0 && x.getInt("awayScore") >= 0))
        }
        ruleRows.forEach { r -> require(r.getLong("bookingId") in bookingIds && r.getString("frequency") in setOf("DAILY", "WEEKLY", "MONTHLY", "WEEKDAYS") && r.optInt("repeatInterval", 1) >= 1 && r.optInt("occurrenceCount") >= 0) }
        eventRows.forEach { e -> require(e.getString("title").isNotBlank()); java.time.LocalDate.parse(e.getString("date")); java.time.LocalTime.parse(e.getString("time")) }
        db.withTransaction {
            db.recurringRuleDao().clearAll(); db.importantEventDao().clearAll(); db.tournamentDao().clearAllMatches(); db.tournamentDao().clearAllTeams()
            db.tournamentDao().clearAll(); db.paymentDao().clearAll(); db.bookingDao().clearAll(); db.appSettingDao().clearAll()
            for (i in 0 until bookings.length()) { val x=bookings.getJSONObject(i); db.bookingDao().insert(Booking(id=x.getLong("id"),customerName=x.getString("customerName"),phone=x.getString("phone"),date=x.getString("date"),startTime=x.getString("startTime"),endTime=x.getString("endTime"),startMinutes=x.getInt("startMinutes"),endMinutes=x.getInt("endMinutes"),teamOne=x.optString("teamOne"),teamTwo=x.optString("teamTwo"),pricePerTeam=x.getLong("pricePerTeam"),paid=x.getLong("paid"),matchType=x.optString("matchType"),tournamentName=x.optString("tournamentName"),tournamentStage=x.optString("tournamentStage"),notes=x.optString("notes"),status=x.optString("status"),createdAt=x.optLong("createdAt"))) }
            for (i in 0 until payments.length()) { val x=payments.getJSONObject(i); db.paymentDao().insert(Payment(id=x.getLong("id"),bookingId=x.getLong("bookingId"),amount=x.getLong("amount"),kind=x.getString("kind"),method=x.optString("method"),note=x.optString("note"),paidAt=x.optLong("paidAt"))) }
            for (i in 0 until tournaments.length()) { val x=tournaments.getJSONObject(i); db.tournamentDao().insert(Tournament(id=x.getLong("id"),name=x.getString("name"),format=x.getString("format"),startDate=x.getString("startDate"),endDate=x.getString("endDate"),status=x.optString("status"),notes=x.optString("notes"),createdAt=x.optLong("createdAt"))) }
            for (i in 0 until teams.length()) { val x=teams.getJSONObject(i); db.tournamentDao().insertTeam(TournamentTeam(id=x.getLong("id"),tournamentId=x.getLong("tournamentId"),name=x.getString("name"),groupName=x.optString("groupName"),played=x.optInt("played"),won=x.optInt("won"),drawn=x.optInt("drawn"),lost=x.optInt("lost"),goalsFor=x.optInt("goalsFor"),goalsAgainst=x.optInt("goalsAgainst"),points=x.optInt("points"))) }
            for (i in 0 until matches.length()) { val x=matches.getJSONObject(i); db.tournamentDao().insertMatch(TournamentMatch(id=x.getLong("id"),tournamentId=x.getLong("tournamentId"),homeTeamId=x.getLong("homeTeamId"),awayTeamId=x.getLong("awayTeamId"),matchDate=x.getString("matchDate"),startTime=x.optString("startTime"),homeScore=if(x.isNull("homeScore")) null else x.getInt("homeScore"),awayScore=if(x.isNull("awayScore")) null else x.getInt("awayScore"),roundName=x.optString("roundName"),status=x.optString("status"))) }
            for (i in 0 until rules.length()) { val x=rules.getJSONObject(i); db.recurringRuleDao().insert(RecurringRule(id=x.getLong("id"),bookingId=x.getLong("bookingId"),frequency=x.getString("frequency"),repeatInterval=x.optInt("repeatInterval",1),weekdaysCsv=x.optString("weekdaysCsv"),untilDate=x.optString("untilDate"),occurrenceCount=x.optInt("occurrenceCount"),active=x.optBoolean("active",true))) }
            for (i in 0 until settings.length()) { val x=settings.getJSONObject(i); db.appSettingDao().put(AppSetting(x.getString("settingKey"),x.getString("value"))) }
            for (i in 0 until events.length()) { val x=events.getJSONObject(i); db.importantEventDao().insert(ImportantEvent(id=x.getLong("id"),title=x.getString("title"),date=x.getString("date"),time=x.getString("time"),notes=x.optString("notes"),createdAt=x.optLong("createdAt"))) }
        }
    }
}
