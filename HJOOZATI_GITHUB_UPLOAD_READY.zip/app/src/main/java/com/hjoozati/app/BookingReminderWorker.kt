package com.hjoozati.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.concurrent.TimeUnit

class BookingReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val title = inputData.getString("title") ?: "Upcoming booking"
        val detail = inputData.getString("detail") ?: "You have a booking soon."
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Booking reminders", NotificationManager.IMPORTANCE_DEFAULT))
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(detail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
        manager.notify(inputData.getLong("bookingId", 0L).toInt(), notification)
        return Result.success()
    }
    companion object {
        private const val CHANNEL = "hjoozati_booking_reminders"
        private fun enqueue(context: Context, uniqueName: String, id: Long, title: String, detail: String, at: java.time.Instant) {
            val now = java.time.Instant.now()
            if (!at.isAfter(now)) return
            val delay = Duration.between(now, at).toMillis()
            val request = OneTimeWorkRequestBuilder<BookingReminderWorker>().setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf("bookingId" to id, "title" to title, "detail" to detail)).build()
            WorkManager.getInstance(context).enqueueUniqueWork(uniqueName, ExistingWorkPolicy.REPLACE, request)
        }
        fun schedule(context: Context, id: Long, customer: String, date: String, time: String, leadMinutes: Long = 60) {
            val start = runCatching { LocalDateTime.of(java.time.LocalDate.parse(date), LocalTime.parse(time)).atZone(ZoneId.systemDefault()).toInstant() }.getOrNull() ?: return
            enqueue(context, "booking-reminder-$id", id, "Booking reminder", "$customer • $date at $time", start.minusSeconds(leadMinutes * 60))
        }
        fun scheduleBalance(context: Context, id: Long, customer: String, date: String, amount: Long) {
            val at = runCatching { LocalDateTime.of(java.time.LocalDate.parse(date).plusDays(1), LocalTime.of(9, 0)).atZone(ZoneId.systemDefault()).toInstant() }.getOrNull() ?: return
            enqueue(context, "balance-reminder-$id", id, "Outstanding booking balance", "$customer • $amount IQD remains unpaid", at)
        }
        fun scheduleTournament(context: Context, id: Long, name: String, date: String) {
            val at = runCatching { LocalDateTime.of(java.time.LocalDate.parse(date).minusDays(1), LocalTime.of(9, 0)).atZone(ZoneId.systemDefault()).toInstant() }.getOrNull() ?: return
            enqueue(context, "tournament-reminder-$id", id, "Tournament starts tomorrow", name, at)
        }
        fun scheduleImportantEvent(context: Context, id: Long, title: String, date: String, time: String, leadMinutes: Long = 60) {
            val at = runCatching { LocalDateTime.of(java.time.LocalDate.parse(date), LocalTime.parse(time)).atZone(ZoneId.systemDefault()).toInstant() }.getOrNull() ?: return
            enqueue(context, "important-event-reminder-$id", id, "Important event", title, at.minusSeconds(leadMinutes * 60))
        }
        fun cancelEvent(context: Context, id: Long) { WorkManager.getInstance(context).cancelUniqueWork("important-event-reminder-$id") }
        fun cancel(context: Context, id: Long) {
            WorkManager.getInstance(context).cancelUniqueWork("booking-reminder-$id")
            WorkManager.getInstance(context).cancelUniqueWork("balance-reminder-$id")
        }
        fun cancelTournament(context: Context, id: Long) { WorkManager.getInstance(context).cancelUniqueWork("tournament-reminder-$id") }
    }
}
