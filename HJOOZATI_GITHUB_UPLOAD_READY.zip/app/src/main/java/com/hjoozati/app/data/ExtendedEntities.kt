package com.hjoozati.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Individual cash movements. Amount is stored in the smallest currency unit used by the app. */
@Entity(tableName = "payments", indices = [Index("bookingId"), Index("paidAt")])
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookingId: Long,
    val amount: Long,
    val kind: String = "PAYMENT", // PAYMENT or REFUND
    val method: String = "CASH",
    val note: String = "",
    val paidAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tournaments", indices = [Index("startDate"), Index("status")])
data class Tournament(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val format: String, // KNOCKOUT, LEAGUE, GROUPS_KNOCKOUT
    val startDate: String,
    val endDate: String,
    val status: String = "PLANNED",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tournament_teams", indices = [Index("tournamentId")])
data class TournamentTeam(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tournamentId: Long,
    val name: String,
    val groupName: String = "",
    val played: Int = 0,
    val won: Int = 0,
    val drawn: Int = 0,
    val lost: Int = 0,
    val goalsFor: Int = 0,
    val goalsAgainst: Int = 0,
    val points: Int = 0
)

@Entity(tableName = "tournament_matches", indices = [Index("tournamentId"), Index("matchDate")])
data class TournamentMatch(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tournamentId: Long,
    val homeTeamId: Long,
    val awayTeamId: Long,
    val matchDate: String,
    val startTime: String = "",
    val homeScore: Int? = null,
    val awayScore: Int? = null,
    val roundName: String = "",
    val status: String = "SCHEDULED"
)

@Entity(tableName = "recurring_rules", indices = [Index("bookingId"), Index("active")])
data class RecurringRule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookingId: Long,
    val frequency: String, // DAILY, WEEKLY, MONTHLY, WEEKDAYS
    val repeatInterval: Int = 1,
    val weekdaysCsv: String = "",
    val untilDate: String = "",
    val occurrenceCount: Int = 0,
    val active: Boolean = true
)

@Entity(tableName = "app_settings")
data class AppSetting(
    @PrimaryKey val settingKey: String,
    val value: String
)

@Entity(tableName = "important_events", indices = [Index("date")])
data class ImportantEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val date: String,
    val time: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
