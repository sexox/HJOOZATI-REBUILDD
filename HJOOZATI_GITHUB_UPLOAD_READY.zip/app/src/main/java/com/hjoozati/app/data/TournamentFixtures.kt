package com.hjoozati.app.data

/** Deterministic fixture generation helpers. A null opponent represents a bye. */
object TournamentFixtures {
    data class Pairing(val home: Long, val away: Long, val round: Int)

    fun roundRobin(teamIds: List<Long>): List<Pairing> {
        require(teamIds.size >= 2) { "At least two teams are required" }
        require(teamIds.distinct().size == teamIds.size) { "Team IDs must be unique" }
        val slots = teamIds.toMutableList<Long?>()
        if (slots.size % 2 != 0) slots += null
        val rounds = slots.size - 1
        val perRound = slots.size / 2
        val result = mutableListOf<Pairing>()
        repeat(rounds) { round ->
            repeat(perRound) { index ->
                val a = slots[index]
                val b = slots[slots.lastIndex - index]
                if (a != null && b != null) {
                    val home = if (round % 2 == 0) a else b
                    val away = if (round % 2 == 0) b else a
                    result += Pairing(home, away, round + 1)
                }
            }
            val fixed = slots.first()
            val rotating = slots.drop(1).toMutableList()
            rotating.add(0, rotating.removeAt(rotating.lastIndex))
            slots.clear(); slots += fixed; slots += rotating
        }
        return result
    }

    fun knockoutFirstRound(teamIds: List<Long>): List<Pairing> {
        require(teamIds.size >= 2) { "At least two teams are required" }
        require(teamIds.distinct().size == teamIds.size) { "Team IDs must be unique" }
        require(teamIds.size.countOneBits() == 1) { "Knockout tournaments require 2, 4, 8, 16, ... teams to avoid unassigned byes" }
        val sorted = teamIds.toList()
        return (0 until sorted.size / 2).map { Pairing(sorted[it], sorted[sorted.lastIndex - it], 1) }
    }

    /** Returns the two cross-group semi-final pairings once every group fixture has a result. */
    fun groupSemiFinals(teams: List<TournamentTeam>, matches: List<TournamentMatch>): List<Pairing> {
        val groups = teams.groupBy { it.groupName.trim().uppercase() }.toSortedMap()
        require(groups.size == 2) { "Group knockout currently requires exactly two groups" }
        require(matches.isNotEmpty() && matches.all { it.homeScore != null && it.awayScore != null }) { "Complete every group match before generating the knockout stage" }
        val qualifiers = groups.values.map { group ->
            val ids = group.map { it.id }.toSet()
            val results = matches.filter { it.homeTeamId in ids && it.awayTeamId in ids }
                .map { BookingRules.MatchResult(it.homeTeamId, it.awayTeamId, it.homeScore!!, it.awayScore!!) }
            val table = BookingRules.standings(group.map { it.id }, results)
            require(table.size >= 2) { "Each group needs at least two teams" }
            table.take(2).map { it.teamId }
        }
        return listOf(Pairing(qualifiers[0][0], qualifiers[1][1], 1), Pairing(qualifiers[1][0], qualifiers[0][1], 1))
    }

    /** Builds the next knockout round from winners of the latest completed knockout round. */
    fun nextKnockoutRound(matches: List<TournamentMatch>): List<Pairing> {
        val knockout = matches.filter { it.roundName.startsWith("Knockout Round ") }
        require(knockout.isNotEmpty()) { "No knockout round exists yet" }
        val latestNumber = knockout.mapNotNull { it.roundName.substringAfterLast(' ').toIntOrNull() }.maxOrNull()
            ?: throw IllegalArgumentException("Invalid knockout round label")
        val latest = knockout.filter { it.roundName == "Knockout Round $latestNumber" }
        require(latest.all { it.homeScore != null && it.awayScore != null }) { "Complete every match in the current round first" }
        val winners = latest.map { match ->
            val homeScore = match.homeScore ?: throw IllegalArgumentException("Complete every match in the current round first")
            val awayScore = match.awayScore ?: throw IllegalArgumentException("Complete every match in the current round first")
            if (homeScore > awayScore) match.homeTeamId
            else if (awayScore > homeScore) match.awayTeamId
            else throw IllegalArgumentException("Knockout matches cannot end in a draw; enter the decided winner's score")
        }
        require(winners.size >= 2 && winners.size % 2 == 0) { "The current round does not produce an even number of teams for the next round" }
        return winners.chunked(2).map { Pairing(it[0], it[1], latestNumber + 1) }
    }

    /** Group-stage round robin. Group names are explicit and teams are never silently mixed. */
    fun groupFixtures(teams: List<TournamentTeam>): List<Pairing> {
        require(teams.all { it.groupName.isNotBlank() }) { "Assign every team to a group first" }
        require(teams.map { it.groupName.trim().uppercase() }.distinct().size == 2) { "Group knockout requires exactly two groups (A and B)" }
        return teams.groupBy { it.groupName.trim().uppercase() }.toSortedMap().values
            .flatMap { group -> if (group.size < 2) emptyList() else roundRobin(group.map { it.id }) }
    }
}
