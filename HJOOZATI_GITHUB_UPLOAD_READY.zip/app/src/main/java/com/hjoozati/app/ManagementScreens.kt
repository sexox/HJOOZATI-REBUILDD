package com.hjoozati.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.UploadFile
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.hjoozati.app.data.AppDatabase
import com.hjoozati.app.data.BackupManager
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hjoozati.app.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

private val MInk = Color(0xFF08070D)
private val MPanel = Color(0xFF17131F)
private val MPurple = Color(0xFFB86CFF)
private val MGold = Color(0xFFF3B94F)
private val MMuted = Color(0xFFAAA2B5)

@Composable
fun TournamentScreen(database: AppDatabase, modifier: Modifier = Modifier) {
    val dao = database.tournamentDao()
    val tournaments by dao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<Tournament?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var showTeam by remember { mutableStateOf(false) }
    var showMatch by remember { mutableStateOf(false) }
    var showEditTournament by remember { mutableStateOf(false) }
    var scoreMatch by remember { mutableStateOf<TournamentMatch?>(null) }
    var fixtureError by remember { mutableStateOf<String?>(null) }
    val teams by (selected?.let { dao.observeTeams(it.id) } ?: kotlinx.coroutines.flow.flowOf<List<TournamentTeam>>(emptyList())).collectAsStateWithLifecycle(initialValue = emptyList())
    val matches by (selected?.let { dao.observeMatches(it.id) } ?: kotlinx.coroutines.flow.flowOf<List<TournamentMatch>>(emptyList())).collectAsStateWithLifecycle(initialValue = emptyList())
    val groupMatches = matches.filter { it.roundName.startsWith("Group stage") }
    val hasKnockout = matches.any { it.roundName.startsWith("Knockout Round ") }
    val nextKnockoutPairs = if (hasKnockout) runCatching { TournamentFixtures.nextKnockoutRound(matches) }.getOrNull() else null

    Column(modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("البطولات", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black); Text("إدارة البطولات والنتائج", color = MMuted, fontSize = 12.sp) }
            IconButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null, tint = MGold) }
        }
        if (selected == null) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
                if (tournaments.isEmpty()) item { ManagementEmpty("لا توجد بطولات حالياً", "أنشئ بطولة لإضافة الفرق والمباريات.") }
                items(tournaments, key = { it.id }) { t ->
                    Column(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(18.dp)).clickable { selected = t }.padding(16.dp)) {
                        Text(t.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("${t.format.replace('_', ' ')}  •  ${t.startDate} – ${t.endDate}", color = MMuted, fontSize = 11.sp)
                        Text(t.status, color = MGold, fontSize = 11.sp)
                    }
                }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selected = null }) { Text("← جميع البطولات", color = MGold) }
                Spacer(Modifier.weight(1f))
                Text(selected!!.name, color = Color.White, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showTeam = true }, colors = ButtonDefaults.buttonColors(containerColor = MPurple)) { Text("إضافة فريق") }
                OutlinedButton(onClick = { showMatch = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MGold)) { Text("إضافة مباراة") }
                if (matches.isEmpty() && teams.size >= 2) OutlinedButton(onClick = {
                    scope.launch {
                        runCatching {
                            val format = selected!!.format
                            val pairs = when (format) {
                                "LEAGUE" -> TournamentFixtures.roundRobin(teams.map { it.id })
                                "GROUPS_KNOCKOUT" -> TournamentFixtures.groupFixtures(teams)
                                else -> TournamentFixtures.knockoutFirstRound(teams.map { it.id })
                            }
                            require(pairs.isNotEmpty()) { "No fixtures generated. Assign teams to groups first." }
                            val base = LocalDate.parse(selected!!.startDate)
                            require(!base.plusDays((pairs.maxOf { it.round } - 1).toLong()).isAfter(LocalDate.parse(selected!!.endDate))) { "Generated fixtures extend beyond the tournament end date" }
                            database.withTransaction {
                                pairs.forEachIndexed { index, pair ->
                                    val roundLabel = when (format) { "LEAGUE" -> "Round ${pair.round}"; "GROUPS_KNOCKOUT" -> "Group stage • Round ${pair.round}"; else -> "Knockout Round 1" }
                                    val slot = pairs.take(index).count { it.round == pair.round }
                                    val time = java.time.LocalTime.of(10, 0).plusHours(slot * 2L).toString()
                                    insertTournamentFixtureSafely(database, selected!!.id, pair.home, pair.away, base.plusDays((pair.round - 1).toLong()).toString(), time, roundLabel)
                                }
                            }
                        }.onSuccess { fixtureError = null }.onFailure { fixtureError = it.message ?: "Could not generate fixtures" }
                    }
                }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MGold)) { Text("إنشاء جدول المباريات") }
            }
            if (selected!!.format == "GROUPS_KNOCKOUT") Text("وزّع الفرق على مجموعتين (A وB). أكمل مباريات المجموعات لفتح مرحلة خروج المغلوب.", color = MMuted, fontSize = 11.sp)
            if (selected!!.format == "GROUPS_KNOCKOUT" && groupMatches.isNotEmpty() && !hasKnockout) {
                OutlinedButton(onClick = {
                    scope.launch {
                        runCatching {
                            val pairs = TournamentFixtures.groupSemiFinals(teams, groupMatches)
                            val date = LocalDate.parse(groupMatches.maxOf { it.matchDate }).plusDays(1)
                            require(!date.isAfter(LocalDate.parse(selected!!.endDate))) { "Knockout stage falls after the tournament end date" }
                            database.withTransaction {
                                pairs.forEachIndexed { index, pair -> insertTournamentFixtureSafely(database, selected!!.id, pair.home, pair.away, date.toString(), java.time.LocalTime.of(18, 0).plusHours(index * 2L).toString(), "Knockout Round 1") }
                            }
                        }.onSuccess { fixtureError = null }.onFailure { fixtureError = it.message ?: "Could not create knockout stage" }
                    }
                }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MGold)) { Text("إنشاء مرحلة خروج المغلوب") }
            }
            if (nextKnockoutPairs != null && nextKnockoutPairs.isNotEmpty()) {
                OutlinedButton(onClick = {
                    scope.launch {
                        runCatching {
                            val date = LocalDate.parse(matches.filter { it.roundName.startsWith("Knockout Round ") }.maxOf { it.matchDate }).plusDays(1)
                            require(!date.isAfter(LocalDate.parse(selected!!.endDate))) { "Next round falls after the tournament end date" }
                            database.withTransaction {
                                nextKnockoutPairs.forEachIndexed { index, pair -> insertTournamentFixtureSafely(database, selected!!.id, pair.home, pair.away, date.toString(), java.time.LocalTime.of(18, 0).plusHours(index * 2L).toString(), "Knockout Round ${pair.round}") }
                            }
                        }.onSuccess { fixtureError = null }.onFailure { fixtureError = it.message ?: "Could not advance bracket" }
                    }
                }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MGold)) { Text("الانتقال إلى الدور التالي") }
            }
            fixtureError?.let { Text(it, color = Color(0xFFFF8888), fontSize = 11.sp) }
            Text("TEAMS & TABLE", color = MGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
            val groupStageMatches = matches.filter { it.roundName.startsWith("Group stage") }
            val leagueTable = BookingRules.standings(teams.map { it.id }, matches.filter { it.homeScore != null && it.awayScore != null }.map { m ->
                BookingRules.MatchResult(m.homeTeamId, m.awayTeamId, m.homeScore!!, m.awayScore!!)
            })
            val groupTables = teams.groupBy { it.groupName.trim().uppercase() }.toSortedMap().mapValues { (_, groupTeams) ->
                val ids = groupTeams.map { it.id }.toSet()
                val results = groupStageMatches.filter { it.homeTeamId in ids && it.awayTeamId in ids && it.homeScore != null && it.awayScore != null }
                    .map { BookingRules.MatchResult(it.homeTeamId, it.awayTeamId, it.homeScore!!, it.awayScore!!) }
                BookingRules.standings(groupTeams.map { it.id }, results)
            }
            val knockoutMatches = matches.filter { it.roundName.startsWith("Knockout Round ") }
            val latestRoundNumber = knockoutMatches.mapNotNull { it.roundName.substringAfterLast(' ').toIntOrNull() }.maxOrNull()
            val latestRoundMatches = latestRoundNumber?.let { n -> knockoutMatches.filter { it.roundName == "Knockout Round $n" } }.orEmpty()
            val championId = if (latestRoundMatches.size == 1 && latestRoundMatches.single().homeScore != null && latestRoundMatches.single().awayScore != null && latestRoundMatches.single().homeScore != latestRoundMatches.single().awayScore) {
                val final = latestRoundMatches.single(); if (final.homeScore!! > final.awayScore!!) final.homeTeamId else final.awayTeamId
            } else null
            championId?.let { id -> Text("CHAMPION  •  ${teams.firstOrNull { it.id == id }?.name ?: "Team $id"}", color = MGold, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 8.dp)) }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selected!!.format == "LEAGUE") {
                    item { Text("LEAGUE TABLE", color = MGold, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    items(leagueTable, key = { it.teamId }) { row ->
                        val team = teams.firstOrNull { it.id == row.teamId }
                        Row(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(12.dp)).padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(team?.name ?: "Team ${row.teamId}", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${row.played} P  •  ${row.points} pts  •  GD ${row.goalDifference}", color = MGold, fontSize = 11.sp)
                        }
                    }
                } else if (selected!!.format == "GROUPS_KNOCKOUT") {
                    groupTables.forEach { (groupName, table) ->
                        item(key = "group-$groupName") { Text("GROUP $groupName", color = MGold, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        items(table, key = { "$groupName-${it.teamId}" }) { row ->
                            val team = teams.firstOrNull { it.id == row.teamId }
                            Row(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(12.dp)).padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(team?.name ?: "Team ${row.teamId}", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("${row.played} P  •  ${row.points} pts  •  GD ${row.goalDifference}", color = MGold, fontSize = 11.sp)
                            }
                        }
                    }
                } else {
                    item { Text("TEAMS", color = MGold, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    items(teams, key = { it.id }) { team -> Text(team.name, color = Color.White, modifier = Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(10.dp)).padding(12.dp)) }
                }
                item { Text("FIXTURES & RESULTS", color = MGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
                items(matches, key = { it.id }) { match ->
                    val home = teams.firstOrNull { it.id == match.homeTeamId }?.name ?: "Team ${match.homeTeamId}"
                    val away = teams.firstOrNull { it.id == match.awayTeamId }?.name ?: "Team ${match.awayTeamId}"
                    Column(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(12.dp)).padding(12.dp)) {
                        Text("$home  ${match.homeScore?.toString() ?: "–"} : ${match.awayScore?.toString() ?: "–"}  $away", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${match.matchDate}  ${match.startTime}  •  ${match.roundName}", color = MMuted, fontSize = 11.sp)
                        TextButton(onClick = { scoreMatch = match }) { Text("Enter / edit result", color = MGold) }
                    }
                }
            }
        }
    }
    if (showCreate) TournamentCreateDialog(onDismiss = { showCreate = false }, onSave = { name, format, start, end -> scope.launch { val id = dao.insert(Tournament(name = name, format = format, startDate = start, endDate = end)); BookingReminderWorker.scheduleTournament(context, id, name, start); showCreate = false } })
    if (showEditTournament && selected != null) TournamentCreateDialog(initial = selected, formatEditable = matches.isEmpty(), onDismiss = { showEditTournament = false }, onSave = { name, format, start, end -> scope.launch {
        runCatching {
            require(matches.all { it.matchDate >= start && it.matchDate <= end }) { "Tournament dates cannot exclude existing fixtures" }
            val updated = selected!!.copy(name = name, format = format, startDate = start, endDate = end)
            dao.update(updated); selected = updated
            BookingReminderWorker.cancelTournament(context, updated.id); BookingReminderWorker.scheduleTournament(context, updated.id, name, start)
            showEditTournament = false
        }.onFailure { fixtureError = it.message ?: "Could not update tournament" }
    } })
    if (showTeam && selected != null) TeamCreateDialog(onDismiss = { showTeam = false }) { name, group -> scope.launch { dao.insertTeam(TournamentTeam(tournamentId = selected!!.id, name = name, groupName = group)); showTeam = false } }
    if (showMatch && selected != null) MatchCreateDialog(teams, onDismiss = { showMatch = false }) { home, away, date, time, round -> scope.launch {
        runCatching { database.withTransaction { insertTournamentFixtureSafely(database, selected!!.id, home, away, date, time, round) } }
            .onSuccess { showMatch = false; fixtureError = null }
            .onFailure { fixtureError = it.message ?: "Could not schedule match" }
    } }
    scoreMatch?.let { match -> ScoreDialog(match, onDismiss = { scoreMatch = null }) { home, away -> scope.launch {
        dao.updateMatch(match.copy(homeScore = home, awayScore = away, status = "PLAYED"))
        val tournamentMatches = dao.getAllMatchesSnapshot().filter { it.tournamentId == match.tournamentId && it.roundName.startsWith("Knockout Round ") }
        val latestRound = tournamentMatches.mapNotNull { it.roundName.substringAfterLast(' ').toIntOrNull() }.maxOrNull()
        val finalRound = latestRound?.let { n -> tournamentMatches.filter { it.roundName == "Knockout Round $n" } }.orEmpty()
        if (finalRound.size == 1 && finalRound.single().homeScore != null && finalRound.single().awayScore != null && finalRound.single().homeScore != finalRound.single().awayScore) {
            dao.get(match.tournamentId)?.let { dao.update(it.copy(status = "COMPLETED")) }
        }
        scoreMatch = null
    } } }
}

private suspend fun insertTournamentFixtureSafely(
    database: AppDatabase, tournamentId: Long, homeTeamId: Long, awayTeamId: Long,
    date: String, startTime: String, roundName: String
) {
    val start = parseMinutes(startTime) ?: throw IllegalArgumentException("Invalid match start time")
    val end = start + 60
    require(end <= 1440) { "Tournament match cannot extend past midnight" }
    val bookingConflict = database.bookingDao().findOverlap(date, start, end, 0L)
    require(bookingConflict == null) { "Tournament fixture conflicts with booking for ${bookingConflict?.customerName}" }
    val endTime = java.time.LocalTime.of(end / 60, end % 60).toString()
    val fixtureConflict = database.tournamentDao().findMatchOverlap(date, startTime, endTime)
    require(fixtureConflict == null) { "Another tournament fixture overlaps this time slot" }
    database.tournamentDao().insertMatch(TournamentMatch(tournamentId = tournamentId, homeTeamId = homeTeamId, awayTeamId = awayTeamId, matchDate = date, startTime = startTime, roundName = roundName))
}

@Composable
private fun TournamentCreateDialog(initial: Tournament? = null, formatEditable: Boolean = true, onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var name by remember(initial?.id) { mutableStateOf(initial?.name ?: "") }; var format by remember(initial?.id) { mutableStateOf(initial?.format ?: "KNOCKOUT") }
    var start by remember(initial?.id) { mutableStateOf(initial?.startDate ?: LocalDate.now().toString()) }; var end by remember(initial?.id) { mutableStateOf(initial?.endDate ?: LocalDate.now().plusMonths(1).toString()) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = MPanel, title = { Text(if (initial == null) "إنشاء بطولة" else "تعديل البطولة") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("اسم البطولة") })
            if (formatEditable) listOf("KNOCKOUT", "LEAGUE", "GROUPS_KNOCKOUT").forEach { f -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(format == f, { format = f }); Text(f.replace('_', ' '), color = Color.White) } }
            else Text("Format locked after fixtures have been created: ${format.replace('_', ' ')}", color = MMuted, fontSize = 11.sp)
            OutlinedTextField(start, { start = it }, label = { Text("Start date YYYY-MM-DD") })
            OutlinedTextField(end, { end = it }, label = { Text("End date YYYY-MM-DD") })
        }
    }, confirmButton = { TextButton(onClick = { if (name.isNotBlank() && runCatching { LocalDate.parse(start); LocalDate.parse(end) }.isSuccess && end >= start) onSave(name.trim(), format, start, end) }) { Text("Create", color = MGold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun TeamCreateDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var group by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = MPanel, title = { Text("إضافة فريق") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("اسم الفريق") }); OutlinedTextField(group, { group = it }, label = { Text("Group (A, B, …) — optional") }) } },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(name.trim(), group.trim()) }) { Text("Save", color = MGold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun SimpleNameDialog(title: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = MPanel, title = { Text(title) }, text = { OutlinedTextField(name, { name = it }, label = { Text("Name") }) }, confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(name.trim()) }) { Text("Save", color = MGold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun MatchCreateDialog(teams: List<TournamentTeam>, onDismiss: () -> Unit, onSave: (Long, Long, String, String, String) -> Unit) {
    var home by remember { mutableLongStateOf(teams.firstOrNull()?.id ?: 0L) }; var away by remember { mutableLongStateOf(teams.getOrNull(1)?.id ?: 0L) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }; var time by remember { mutableStateOf("19:00") }; var round by remember { mutableStateOf("Round 1") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = MPanel, title = { Text("Schedule match") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            if (teams.size < 2) Text("Add at least two teams first", color = MGold)
            teams.forEach { team -> Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(home == team.id, { home = team.id }); Text("Home: ${team.name}", color = Color.White); RadioButton(away == team.id, { away = team.id }); Text("Away", color = Color.White) } }
            OutlinedTextField(date, { date = it }, label = { Text("التاريخ سنة-شهر-يوم") }); OutlinedTextField(time, { time = it }, label = { Text("Time") }); OutlinedTextField(round, { round = it }, label = { Text("الجولة") })
        }
    }, confirmButton = { TextButton(enabled = teams.size >= 2 && home != away, onClick = { if (runCatching { LocalDate.parse(date) }.isSuccess) onSave(home, away, date, time, round) }) { Text("Save", color = MGold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun ScoreDialog(match: TournamentMatch, onDismiss: () -> Unit, onSave: (Int, Int) -> Unit) {
    var home by remember(match.id) { mutableStateOf(match.homeScore?.toString() ?: "0") }
    var away by remember(match.id) { mutableStateOf(match.awayScore?.toString() ?: "0") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = MPanel, title = { Text("Match result") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (match.roundName.startsWith("Knockout Round")) Text("Knockout matches need a winner. If decided by penalties, enter the decisive result here.", color = MMuted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(home, { home = it.filter(Char::isDigit).take(2) }, label = { Text("Home") }, modifier = Modifier.weight(1f))
            OutlinedTextField(away, { away = it.filter(Char::isDigit).take(2) }, label = { Text("Away") }, modifier = Modifier.weight(1f))
            }
        } },
        confirmButton = { TextButton(onClick = { val h = home.toIntOrNull(); val a = away.toIntOrNull(); if (h != null && a != null) onSave(h, a) }) { Text("حفظ النتيجة", color = MGold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun CalendarScreen(bookings: List<Booking>, database: AppDatabase, modifier: Modifier = Modifier, onEdit: (Booking) -> Unit = {}) {
    val eventDao = database.importantEventDao()
    val events by eventDao.observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val tournaments by database.tournamentDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    val fixtures by database.tournamentDao().observeAllMatches().collectAsStateWithLifecycle(initialValue = emptyList())
    val allTeams by database.tournamentDao().observeAllTeams().collectAsStateWithLifecycle(initialValue = emptyList())
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var mode by remember { mutableStateOf("شهر") }
    var showEventEditor by remember { mutableStateOf(false) }
    var editingEvent by remember { mutableStateOf<ImportantEvent?>(null) }
    val days = month.lengthOfMonth()
    val firstOffset = month.atDay(1).dayOfWeek.value - 1
    val weekStart = selected.with(java.time.DayOfWeek.MONDAY)
    val weekDates = (0..6).map { weekStart.plusDays(it.toLong()) }
    val selectedBookings = bookings.filter { it.date == selected.toString() }.sortedBy { it.startMinutes }
    val selectedEvents = events.filter { it.date == selected.toString() }.sortedBy { it.time }
    val selectedFixtures = fixtures.filter { it.matchDate == selected.toString() }.sortedBy { it.startTime }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("تقويم الحجوزات", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 20.dp))
            IconButton(onClick = { editingEvent = null; showEventEditor = true }) { Icon(Icons.Default.Add, "إضافة مناسبة", tint = MGold) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)) {
            listOf("يوم", "أسبوع", "شهر").forEach { option -> FilterChip(selected = mode == option, onClick = { mode = option }, label = { Text(option) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MPurple, selectedLabelColor = Color.White)) }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { when (mode) { "يوم" -> selected = selected.minusDays(1); "أسبوع" -> selected = selected.minusWeeks(1); else -> month = month.minusMonths(1) } }) { Text("‹", color = MGold, fontSize = 24.sp) }
            Text(when (mode) { "يوم" -> selected.toString(); "أسبوع" -> "${weekDates.first()} – ${weekDates.last()}"; else -> month.month.name + " ${month.year}" }, color = MGold, fontWeight = FontWeight.Bold)
            TextButton(onClick = { when (mode) { "يوم" -> selected = selected.plusDays(1); "أسبوع" -> selected = selected.plusWeeks(1); else -> month = month.plusMonths(1) } }) { Text("›", color = MGold, fontSize = 24.sp) }
        }
        if (mode == "شهر") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { listOf("M", "T", "W", "T", "F", "S", "S").forEach { Text(it, color = MMuted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
            for (week in 0..5) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0..6) {
                        val day = week * 7 + col - firstOffset + 1
                        Box(Modifier.weight(1f).padding(3.dp).aspectRatio(1f).background(if (day in 1..days && selected == month.atDay(day)) MPurple.copy(.35f) else MPanel, RoundedCornerShape(10.dp)).clickable { if (day in 1..days) selected = month.atDay(day) }, contentAlignment = Alignment.Center) {
                            if (day in 1..days) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(day.toString(), color = Color.White)
                                val date = month.atDay(day).toString()
                                if (bookings.any { it.date == date && it.status != "ملغي" && it.status != "CANCELLED" } || events.any { it.date == date } || fixtures.any { it.matchDate == date }) Box(Modifier.size(5.dp).background(MGold, RoundedCornerShape(50)))
                            }
                        }
                    }
                }
            }
        } else if (mode == "أسبوع") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                weekDates.forEach { date ->
                    val count = bookings.count { it.date == date.toString() && it.status != "ملغي" && it.status != "CANCELLED" } + events.count { it.date == date.toString() } + fixtures.count { it.matchDate == date.toString() }
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(if (date == selected) MPurple.copy(.35f) else MPanel).clickable { selected = date }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(date.dayOfWeek.name.take(1), color = MMuted, fontSize = 10.sp)
                        Text(date.dayOfMonth.toString(), color = Color.White, fontWeight = FontWeight.Bold)
                        Text(count.toString(), color = MGold, fontSize = 10.sp)
                    }
                }
            }
        }
        Text("${selected.toString()}  •  ${selectedBookings.size} bookings • ${selectedEvents.size} events • ${selectedFixtures.size} fixtures", color = MGold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp))
        if (selectedBookings.isEmpty() && selectedEvents.isEmpty() && selectedFixtures.isEmpty()) ManagementEmpty("لا توجد عناصر", "لا توجد حجوزات أو مناسبات أو مباريات في هذا التاريخ.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(selectedBookings, key = { "booking-${it.id}" }) { b ->
                Column(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(12.dp)).clickable { onEdit(b) }.padding(12.dp)) {
                    Text("${b.startTime}–${b.endTime}  ${b.customerName}", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("${b.teamOne} vs ${b.teamTwo} • ${when (b.status) { "مؤكد", "CONFIRMED" -> "Confirmed"; "بانتظار التأكيد", "PENDING" -> "Pending"; "ملغي", "CANCELLED" -> "Cancelled"; "مكتمل", "COMPLETED" -> "Completed"; else -> b.status }}", color = MMuted, fontSize = 11.sp)
                }
            }
            items(selectedFixtures, key = { "fixture-${it.id}" }) { fixture ->
                val tournamentName = tournaments.firstOrNull { it.id == fixture.tournamentId }?.name ?: "Tournament"
                val homeName = allTeams.firstOrNull { it.id == fixture.homeTeamId }?.name ?: "Home"
                val awayName = allTeams.firstOrNull { it.id == fixture.awayTeamId }?.name ?: "Away"
                Column(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text("${fixture.startTime} • $tournamentName", color = MGold, fontWeight = FontWeight.Bold)
                    Text("$homeName  ${fixture.homeScore?.toString() ?: "–"} : ${fixture.awayScore?.toString() ?: "–"}  $awayName", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(fixture.roundName, color = MMuted, fontSize = 11.sp)
                }
            }
            items(selectedEvents, key = { "event-${it.id}" }) { event ->
                Row(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("${event.time} • ${event.title}", color = MGold, fontWeight = FontWeight.Bold); if (event.notes.isNotBlank()) Text(event.notes, color = MMuted, fontSize = 11.sp) }
                    TextButton(onClick = { editingEvent = event; showEventEditor = true }) { Text("تعديل", color = MGold) }
                    TextButton(onClick = { scope.launch { eventDao.delete(event.id); BookingReminderWorker.cancelEvent(context, event.id) } }) { Text("حذف", color = Color(0xFFFF8888)) }
                }
            }
        }
    }
    if (showEventEditor) ImportantEventDialog(initial = editingEvent, onDismiss = { showEventEditor = false }) { title, date, time, notes ->
        scope.launch {
            val id = if (editingEvent == null) eventDao.insert(ImportantEvent(title = title, date = date, time = time, notes = notes)) else editingEvent!!.id.also { eventDao.update(editingEvent!!.copy(title = title, date = date, time = time, notes = notes)) }
            BookingReminderWorker.cancelEvent(context, id)
            val lead = database.appSettingDao().get("reminder_lead_minutes")?.toLongOrNull() ?: 60L
            BookingReminderWorker.scheduleImportantEvent(context, id, title, date, time, lead)
            showEventEditor = false
        }
    }
}

@Composable
private fun ImportantEventDialog(initial: ImportantEvent?, onDismiss: () -> Unit, onSave: (String, String, String, String) -> Unit) {
    var title by remember(initial?.id) { mutableStateOf(initial?.title ?: "") }
    var date by remember(initial?.id) { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var time by remember(initial?.id) { mutableStateOf(initial?.time ?: "09:00") }
    var notes by remember(initial?.id) { mutableStateOf(initial?.notes ?: "") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = MPanel, title = { Text(if (initial == null) "مناسبة جديدة" else "تعديل المناسبة") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("عنوان المناسبة") })
            OutlinedTextField(date, { date = it }, label = { Text("التاريخ سنة-شهر-يوم") })
            OutlinedTextField(time, { time = it }, label = { Text("الوقت ساعة:دقيقة") })
            OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
        } },
        confirmButton = { TextButton(onClick = { if (title.isNotBlank() && runCatching { LocalDate.parse(date); java.time.LocalTime.parse(time) }.isSuccess) onSave(title.trim(), date, time, notes.trim()) }) { Text("حفظ المناسبة", color = MGold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun SettingsScreen(database: AppDatabase, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var restoreText by remember { mutableStateOf<String?>(null) }
    var confirmRestore by remember { mutableStateOf(false) }
    var reminderLead by remember { mutableFloatStateOf(60f) }
    val defaultWhatsAppTemplate = "مرحباً {name}، تم تأكيد حجزكم بتاريخ {date} من {start} إلى {end}.\nالإجمالي: {total} د.ع\nالمدفوع: {paid} د.ع\nالمتبقي: {due} د.ع\n{tournament}"
    var whatsappTemplate by remember { mutableStateOf(defaultWhatsAppTemplate) }
    LaunchedEffect(context) { whatsappTemplate = context.getSharedPreferences("hjoozati_preferences", android.content.Context.MODE_PRIVATE).getString("whatsapp_template", defaultWhatsAppTemplate) ?: defaultWhatsAppTemplate }
    LaunchedEffect(database) { reminderLead = database.appSettingDao().get("reminder_lead_minutes")?.toFloatOrNull() ?: 60f }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { runCatching { val json = withContext(Dispatchers.IO) { BackupManager(database).exportJson() }; withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json) } ?: error("Cannot open backup destination") } }.onSuccess { message = "Backup exported successfully" }.onFailure { message = it.message ?: "Backup failed" } }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { runCatching { withContext(Dispatchers.IO) { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Cannot read backup file") } }.onSuccess { restoreText = it; confirmRestore = true }.onFailure { message = it.message ?: "Cannot read backup" } }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> message = if (granted) "تم تفعيل الإشعارات" else "لم تتم الموافقة على صلاحية الإشعارات" }
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("الإعدادات", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 22.dp, bottom = 16.dp))
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).background(MPanel, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("التطبيق", color = MGold, fontWeight = FontWeight.Bold); Text("HJOOZATI • Version 1.1.0", color = MMuted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp)); Text("All booking and tournament data stays on this device unless you export a backup.", color = MMuted, fontSize = 12.sp)
        }
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).background(MPanel, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("رسالة واتساب للحجز", color = MGold, fontWeight = FontWeight.Bold)
            Text("يمكنك تعديل نص الرسالة. المتغيرات المتاحة: {name} {date} {start} {end} {total} {paid} {due} {tournament}", color = MMuted, fontSize = 11.sp)
            OutlinedTextField(value = whatsappTemplate, onValueChange = { whatsappTemplate = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp), minLines = 4, label = { Text("نص الرسالة") }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MGold, unfocusedBorderColor = MMuted, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
            TextButton(onClick = { context.getSharedPreferences("hjoozati_preferences", android.content.Context.MODE_PRIVATE).edit().putString("whatsapp_template", whatsappTemplate).apply(); message = "تم حفظ قالب واتساب" }) { Text("حفظ رسالة واتساب", color = MGold) }
        }
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).background(MPanel, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("النسخ الاحتياطي والاستعادة", color = MGold, fontWeight = FontWeight.Bold)
            Text("تصدير الحجوزات والمدفوعات والبطولات والمباريات والمناسبات والإعدادات إلى ملف JSON. الاستعادة تستبدل البيانات المحلية الحالية.", color = MMuted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
                Button(onClick = { exportLauncher.launch("hjoozati-backup-${LocalDate.now()}.json") }, colors = ButtonDefaults.buttonColors(containerColor = MPurple)) { Icon(Icons.Default.CloudDownload, null); Spacer(Modifier.width(5.dp)); Text("تصدير") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/json", "*/*")) }, colors = ButtonDefaults.outlinedButtonColors(contentColor = MGold)) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(5.dp)); Text("استعادة") }
            }
        }
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).background(MPanel, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("الإشعارات", color = MGold, fontWeight = FontWeight.Bold)
            Text("حدد المدة التي تسبق الحجز لوصول التذكير.", color = MMuted, fontSize = 12.sp)
            Text("${reminderLead.toInt()} minutes before", color = MGold, fontWeight = FontWeight.Bold)
            Slider(value = reminderLead, onValueChange = { reminderLead = it }, valueRange = 0f..360f, steps = 11, colors = SliderDefaults.colors(thumbColor = MGold, activeTrackColor = MPurple))
            TextButton(onClick = { scope.launch { database.appSettingDao().put(AppSetting("reminder_lead_minutes", reminderLead.toInt().toString())); val all = withContext(Dispatchers.IO) { database.bookingDao().getAllSnapshot() }; all.filter { it.status != "ملغي" && it.status != "CANCELLED" && it.status != "COMPLETED" }.forEach { booking -> BookingReminderWorker.cancel(context, booking.id); BookingReminderWorker.schedule(context, booking.id, booking.customerName, booking.date, booking.startTime, reminderLead.toLong()); if (booking.remaining > 0L) BookingReminderWorker.scheduleBalance(context, booking.id, booking.customerName, booking.date, booking.remaining) }; message = "تم حفظ إعدادات التذكير" } }) { Text("حفظ توقيت التذكير", color = MGold) }
            TextButton(onClick = { if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else message = "صلاحية الإشعارات متاحة" }) { Text("تفعيل صلاحية الإشعارات", color = MGold) }
        }
        Column(Modifier.fillMaxWidth().background(MPanel, RoundedCornerShape(16.dp)).padding(16.dp)) { Text("المظهر", color = MGold, fontWeight = FontWeight.Bold); Text("هوية ثابتة بالبنفسجي والذهبي والأسود", color = MMuted, fontSize = 12.sp) }
        message?.let { Text(it, color = MGold, modifier = Modifier.padding(top = 12.dp)) }
    }
    if (confirmRestore) AlertDialog(onDismissRequest = { confirmRestore = false; restoreText = null }, containerColor = MPanel, title = { Text("استبدال البيانات المحلية؟") }, text = { Text("Restoring this backup will replace all current bookings, payments, tournaments and settings. This cannot be undone.") }, confirmButton = { TextButton(onClick = { val json = restoreText; confirmRestore = false; restoreText = null; if (json != null) scope.launch {
                        val oldBookings = database.bookingDao().getAllSnapshot()
                        val oldTournaments = database.tournamentDao().getAllSnapshot()
                        val oldEvents = database.importantEventDao().getAllSnapshot()
                        oldBookings.forEach { BookingReminderWorker.cancel(context, it.id) }
                        oldTournaments.forEach { BookingReminderWorker.cancelTournament(context, it.id) }
                        oldEvents.forEach { BookingReminderWorker.cancelEvent(context, it.id) }
                        runCatching { withContext(Dispatchers.IO) { BackupManager(database).restoreJson(json) } }.onSuccess {
                            val restoredLead = database.appSettingDao().get("reminder_lead_minutes")?.toFloatOrNull() ?: 60f
                            reminderLead = restoredLead
                            val restoredBookings = database.bookingDao().getAllSnapshot()
                            restoredBookings.filter { it.status != "ملغي" && it.status != "CANCELLED" && it.status != "COMPLETED" }.forEach { booking -> BookingReminderWorker.schedule(context, booking.id, booking.customerName, booking.date, booking.startTime, restoredLead.toLong()); if (booking.remaining > 0L) BookingReminderWorker.scheduleBalance(context, booking.id, booking.customerName, booking.date, booking.remaining) }
                            val restoredTournaments = database.tournamentDao().getAllSnapshot()
                            restoredTournaments.filter { it.status == "PLANNED" }.forEach { BookingReminderWorker.scheduleTournament(context, it.id, it.name, it.startDate) }
                            val restoredEvents = database.importantEventDao().getAllSnapshot()
                            restoredEvents.forEach { BookingReminderWorker.scheduleImportantEvent(context, it.id, it.title, it.date, it.time, restoredLead.toLong()) }
                            message = "Backup restored successfully"
                        }.onFailure { message = it.message ?: "Restore failed" } } }) { Text("استعادة البيانات", color = MGold) } }, dismissButton = { TextButton(onClick = { confirmRestore = false; restoreText = null }) { Text("إلغاء") } })
}

@Composable
private fun ManagementEmpty(title: String, description: String) { Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.EmojiEvents, null, tint = MPurple, modifier = Modifier.size(36.dp)); Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(description, color = MMuted, fontSize = 12.sp) } }
