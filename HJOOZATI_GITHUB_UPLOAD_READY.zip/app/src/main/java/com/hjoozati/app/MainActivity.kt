package com.hjoozati.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.work.WorkManager
import com.hjoozati.app.data.BackupManager
import com.hjoozati.app.data.RecurringRule
import java.io.BufferedReader
import java.io.InputStreamReader
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.AndroidViewModel
import android.app.Application
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.hjoozati.app.data.AppDatabase
import com.hjoozati.app.data.Booking
import com.hjoozati.app.data.BookingDao
import com.hjoozati.app.data.BookingFinanceRepository
import com.hjoozati.app.data.PaymentDao
import com.hjoozati.app.data.Payment
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val Ink = Color(0xFF08070D)
private val Panel = Color(0xFF17131F)
private val Panel2 = Color(0xFF21192D)
private val Purple = Color(0xFFB86CFF)
private val PurpleDeep = Color(0xFF7628C7)
private val Gold = Color(0xFFF3B94F)
private val Muted = Color(0xFFAAA2B5)
private val Good = Color(0xFF63D6A2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val database = AppDatabase.get(this)
        val dao = database.bookingDao()
        setContent {
            val vm: BookingViewModel = viewModel(factory = BookingViewModel.Factory(application, database))
            HjoozatiApp(vm, database)
        }
    }
}

class BookingViewModel(application: Application, private val database: AppDatabase) : AndroidViewModel(application) {
    private val dao = database.bookingDao()
    val bookings = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    var message by mutableStateOf<String?>(null)
        private set

    fun clearMessage() { message = null }

    fun save(booking: Booking) = viewModelScope.launch {
        var savedId = booking.id
        if (booking.status != "ملغي" && booking.status != "CANCELLED") {
            val conflict = dao.findOverlap(booking.date, booking.startMinutes, booking.endMinutes, booking.id)
            if (conflict != null) {
                message = "Time conflict with ${conflict.customerName} (${conflict.startTime}–${conflict.endTime})"
                return@launch
            }
            val tournamentConflict = database.tournamentDao().findMatchOverlap(booking.date, booking.startTime, booking.endTime)
            if (tournamentConflict != null) {
                message = "Time conflicts with tournament fixture ${tournamentConflict.roundName} (${tournamentConflict.startTime})"
                return@launch
            }
        }
        runCatching {
            database.withTransaction {
                if (booking.id == 0L) {
                    val id = dao.insert(booking)
                    savedId = id
                    if (booking.paid > 0L) database.paymentDao().insert(
                        Payment(bookingId = id, amount = booking.paid, kind = "PAYMENT", method = "OPENING_BALANCE", note = "Initial amount entered when booking was created")
                    )
                } else {
                    val existing = dao.getById(booking.id) ?: throw IllegalArgumentException("Booking not found")
                    // Payment changes must go through the ledger dialog, never overwrite ledger totals.
                    require(booking.total >= existing.paid) { "New booking total cannot be lower than the amount already collected" }
                    dao.update(booking.copy(paid = existing.paid))
                }
            }
        }.onSuccess {
            if (savedId > 0L) {
                BookingReminderWorker.cancel(getApplication(), savedId)
                if (booking.status != "ملغي" && booking.status != "CANCELLED" && booking.status != "COMPLETED" && booking.status != "مكتمل") {
                    val lead = database.appSettingDao().get("reminder_lead_minutes")?.toLongOrNull() ?: 60L
                    BookingReminderWorker.schedule(getApplication(), savedId, booking.customerName, booking.date, booking.startTime, lead)
                    if (booking.remaining > 0L) BookingReminderWorker.scheduleBalance(getApplication(), savedId, booking.customerName, booking.date, booking.remaining)
                }
            }
            message = "تم حفظ الحجز"
        }.onFailure { message = it.message ?: "تعذر حفظ الحجز" }
    }

    fun saveRecurring(booking: Booking, frequency: String, untilDate: String, count: Int) = viewModelScope.launch {
        runCatching {
            val startDate = LocalDate.parse(booking.date)
            val until = LocalDate.parse(untilDate)
            val dates = com.hjoozati.app.data.BookingRules.occurrences(startDate, frequency, until = until, count = count)
            require(dates.isNotEmpty()) { "No recurring dates were generated" }
            require(dates.size <= 120) { "A recurring series is limited to 120 bookings" }
            val conflicts = dates.mapNotNull { date -> dao.findOverlap(date.toString(), booking.startMinutes, booking.endMinutes, 0)?.let { date to it } }
            require(conflicts.isEmpty()) { "Conflict on ${conflicts.first().first}: ${conflicts.first().second.customerName}" }
            val tournamentConflicts = dates.mapNotNull { date -> database.tournamentDao().findMatchOverlap(date.toString(), booking.startTime, booking.endTime)?.let { date to it } }
            require(tournamentConflicts.isEmpty()) { "Tournament fixture conflict on ${tournamentConflicts.first().first}" }
            val created = mutableListOf<Pair<Long, LocalDate>>()
            database.withTransaction {
                var firstId = 0L
                dates.forEachIndexed { index, date ->
                    val copy = booking.copy(id = 0, date = date.toString(), paid = if (index == 0) booking.paid else 0L)
                    val id = dao.insert(copy)
                    created += id to date
                    if (index == 0) firstId = id
                    if (copy.paid > 0L) database.paymentDao().insert(Payment(bookingId = id, amount = copy.paid, kind = "PAYMENT", method = "OPENING_BALANCE", note = "Initial amount entered when booking was created"))
                }
                database.recurringRuleDao().insert(RecurringRule(bookingId = firstId, frequency = frequency, untilDate = untilDate, occurrenceCount = dates.size))
            }
            message = "Created ${dates.size} bookings"
            val lead = database.appSettingDao().get("reminder_lead_minutes")?.toLongOrNull() ?: 60L
            created.forEach { (id, date) ->
                BookingReminderWorker.schedule(getApplication(), id, booking.customerName, date.toString(), booking.startTime, lead)
                if (booking.remaining > 0L) BookingReminderWorker.scheduleBalance(getApplication(), id, booking.customerName, date.toString(), booking.remaining)
            }
        }.onFailure { message = it.message ?: "Could not create recurring bookings" }
    }

    fun delete(booking: Booking) = viewModelScope.launch {
        BookingReminderWorker.cancel(getApplication(), booking.id)
        database.withTransaction {
            database.paymentDao().deleteForBooking(booking.id)
            database.recurringRuleDao().deleteForBooking(booking.id)
            dao.delete(booking)
        }
        message = "تم حذف الحجز"
    }

    fun updateStatus(booking: Booking, status: String) = viewModelScope.launch {
        dao.update(booking.copy(status = status))
        if (status == "ملغي" || status == "CANCELLED" || status == "COMPLETED") BookingReminderWorker.cancel(getApplication(), booking.id)
        else {
            BookingReminderWorker.cancel(getApplication(), booking.id)
            val lead = database.appSettingDao().get("reminder_lead_minutes")?.toLongOrNull() ?: 60L
            BookingReminderWorker.schedule(getApplication(), booking.id, booking.customerName, booking.date, booking.startTime, lead)
            if (booking.remaining > 0L) BookingReminderWorker.scheduleBalance(getApplication(), booking.id, booking.customerName, booking.date, booking.remaining)
        }
    }

    class Factory(private val application: Application, private val database: AppDatabase) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = BookingViewModel(application, database) as T
    }
}

@Composable
private fun HjoozatiApp(vm: BookingViewModel, database: AppDatabase) {
    val bookings by vm.bookings.collectAsStateWithLifecycle()
    val payments by database.paymentDao().observeAll().collectAsStateWithLifecycle(initialValue = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var editor by remember { mutableStateOf<Booking?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var financeBooking by remember { mutableStateOf<Booking?>(null) }
    val today = LocalDate.now().toString()
    val todayBookings = bookings.filter { it.date == today && it.status != "ملغي" && it.status != "CANCELLED" }
    val zone = java.time.ZoneId.systemDefault()
    val todayStart = LocalDate.now().atStartOfDay(zone).toInstant().toEpochMilli()
    val tomorrowStart = LocalDate.now().plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val monthStart = LocalDate.now().withDayOfMonth(1).atStartOfDay(zone).toInstant().toEpochMilli()
    val todayIncome = payments.filter { it.paidAt >= todayStart && it.paidAt < tomorrowStart }.sumOf { if (it.kind == "REFUND") -it.amount else it.amount }
    val monthIncome = payments.filter { it.paidAt >= monthStart }.sumOf { if (it.kind == "REFUND") -it.amount else it.amount }
    val totalDue = bookings.filter { it.status != "ملغي" && it.status != "CANCELLED" }.sumOf { it.remaining }
    val completedCount = bookings.count { it.status == "مكتمل" || it.status == "COMPLETED" }
    val cancelledCount = bookings.count { it.status == "ملغي" || it.status == "CANCELLED" }
    val snackbar = remember { SnackbarHostState() }
    val uiScope = rememberCoroutineScope()
    val appContext = LocalContext.current
    LaunchedEffect(vm.message) {
        vm.message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Gold, background = Ink, surface = Panel,
        onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
    )) {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Ink,
            snackbarHost = { SnackbarHost(snackbar) },
            floatingActionButton = {
                FloatingActionButton(onClick = { editor = null; showEditor = true }, containerColor = Gold, contentColor = Ink) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة حجز")
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Purple) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("الحجوزات") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("التقويم") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.EmojiEvents, null) }, label = { Text("البطولات") })
                    NavigationBarItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("الإعدادات") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> DashboardScreen(bookings, todayBookings.size, todayIncome, monthIncome, totalDue, completedCount, cancelledCount, Modifier.padding(padding), onAdd = { editor = null; showEditor = true }, onEdit = { editor = it; showEditor = true }, onDelete = vm::delete, onFinance = { financeBooking = it }, onDuplicate = { vm.save(it.copy(id = 0L, paid = 0L, status = "مؤكد", createdAt = System.currentTimeMillis())) })
                1 -> BookingsScreen(bookings, Modifier.padding(padding), onEdit = { editor = it; showEditor = true }, onDelete = vm::delete, onStatus = vm::updateStatus, onFinance = { financeBooking = it }, onDuplicate = { vm.save(it.copy(id = 0L, paid = 0L, status = "مؤكد", createdAt = System.currentTimeMillis())) })
                2 -> CalendarScreen(bookings, database, Modifier.padding(padding), onEdit = { editor = it; showEditor = true })
                3 -> TournamentScreen(database, Modifier.padding(padding))
                else -> SettingsScreen(database, Modifier.padding(padding))
            }
            if (showEditor) {
                BookingEditor(initial = editor, onDismiss = { showEditor = false }, onSave = { vm.save(it); showEditor = false }, onSaveRecurring = { booking, frequency, until, count -> vm.saveRecurring(booking, frequency, until, count); showEditor = false })
            }
            financeBooking?.let { booking ->
                PaymentLedgerDialog(
                    booking = booking,
                    paymentDao = database.paymentDao(),
                    onDismiss = { financeBooking = null },
                    onEntry = { amount, refund, method, note ->
                        uiScope.launch {
                            runCatching {
                                val repo = BookingFinanceRepository(database)
                                if (refund) repo.recordRefund(booking.id, amount, method, note)
                                else repo.recordPayment(booking.id, amount, method, note)
                            }.onSuccess {
                                val updated = database.bookingDao().getById(booking.id)
                                if (updated != null) {
                                    if (updated.remaining > 0L) BookingReminderWorker.scheduleBalance(context = appContext, id = updated.id, customer = updated.customerName, date = updated.date, amount = updated.remaining)
                                    else WorkManager.getInstance(appContext).cancelUniqueWork("balance-reminder-${updated.id}")
                                }
                                snackbar.showSnackbar(if (refund) "Refund recorded" else "Payment recorded")
                            }.onFailure { snackbar.showSnackbar(it.message ?: "Could not save finance entry") }
                        }
                    }
                )
            }
        }
      }
    }
}

@Composable
private fun DashboardScreen(
    bookings: List<Booking>, todayCount: Int, todayIncome: Long, monthIncome: Long, due: Long, completedCount: Int, cancelledCount: Int, modifier: Modifier,
    onAdd: () -> Unit, onEdit: (Booking) -> Unit, onDelete: (Booking) -> Unit, onFinance: (Booking) -> Unit, onDuplicate: (Booking) -> Unit
) {
    val today = LocalDate.now().toString()
    val upcoming = bookings.filter { it.date >= today && it.status != "ملغي" && it.status != "CANCELLED" }.take(4)
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 26.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("مرحباً بعودتك", color = Muted, fontSize = 13.sp)
                    Text("HJOOZATI", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("إدارة حجوزاتك بسهولة", color = Gold, fontSize = 12.sp)
                }
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(PurpleDeep, Gold))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.SportsSoccer, null, tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF39204F), Color(0xFF17121F), Color(0xFF30200F)))).border(1.dp, Purple.copy(alpha = .45f), RoundedCornerShape(24.dp)).padding(20.dp)) {
                Column {
                    Text("ملخص اليوم", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("${LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MiniMetric("حجوزات اليوم", todayCount.toString(), Purple)
                        MiniMetric("المقبوض اليوم", money(todayIncome), Gold)
                        MiniMetric("مقبوضات الشهر", money(monthIncome), Good)
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MiniMetric("إجمالي الحجوزات", bookings.size.toString(), Color.White)
                        MiniMetric("مكتملة", completedCount.toString(), Good)
                        MiniMetric("ملغاة", cancelledCount.toString(), Color(0xFFFF7777))
                    }
                    Spacer(Modifier.height(10.dp))
                    MiniMetric("المبالغ المتبقية", "${money(due)} IQD", Gold)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("الحجوزات القادمة", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("${upcoming.size} upcoming", color = Gold, fontSize = 12.sp)
            }
        }
        if (upcoming.isEmpty()) item { EmptyState("لا توجد حجوزات قادمة", "اضغط + لإنشاء أول حجز") }
        items(upcoming, key = { it.id }) { BookingCard(it, onEdit, onDelete, onFinance, onDuplicate) }
        item { OutlinedButton(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold), border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = .65f))) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إضافة حجز") } }
    }
}

@Composable
private fun MiniMetric(label: String, value: String, color: Color) {
    Column {
        Text(label, color = Muted, fontSize = 10.sp)
        Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BookingsScreen(bookings: List<Booking>, modifier: Modifier, onEdit: (Booking) -> Unit, onDelete: (Booking) -> Unit, onStatus: (Booking, String) -> Unit, onFinance: (Booking) -> Unit, onDuplicate: (Booking) -> Unit) {
    var filter by remember { mutableStateOf("الكل") }
    var search by remember { mutableStateOf("") }
    val statusFiltered = when (filter) {
        "Confirmed" -> bookings.filter { it.status == "CONFIRMED" || it.status == "مؤكد" }
        "Pending" -> bookings.filter { it.status == "PENDING" || it.status == "بانتظار التأكيد" }
        "Completed" -> bookings.filter { it.status == "COMPLETED" || it.status == "مكتمل" }
        "Cancelled" -> bookings.filter { it.status == "ملغي" || it.status == "CANCELLED" }
        else -> bookings
    }
    val filtered = statusFiltered.filter { booking -> search.isBlank() || listOf(booking.customerName, booking.phone, booking.teamOne, booking.teamTwo, booking.date).any { it.contains(search.trim(), ignoreCase = true) } }
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Text("Bookings", fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 25.dp, bottom = 12.dp))
        OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("ابحث باسم العميل أو الهاتف أو الفريق أو التاريخ") }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF51465E), focusedLabelColor = Gold, cursorColor = Gold, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("الكل", "Confirmed", "Pending", "Completed", "Cancelled").forEach { label ->
                FilterChip(selected = filter == label, onClick = { filter = label }, label = { Text(label) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurpleDeep, selectedLabelColor = Color.White))
            }
        }
        LazyColumn(contentPadding = PaddingValues(top = 12.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (filtered.isEmpty()) item { EmptyState("No bookings yet", "Add your first booking with +") }
            items(filtered, key = { it.id }) { booking ->
                Column {
                    BookingCard(booking, onEdit, onDelete, onFinance, onDuplicate)
                    if (booking.status != "ملغي" && booking.status != "CANCELLED" && booking.status != "COMPLETED" && booking.status != "مكتمل") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onStatus(booking, "PENDING") }) { Text("Pending", color = Gold) }
                            TextButton(onClick = { onStatus(booking, "CONFIRMED") }) { Text("Confirm", color = Good) }
                            TextButton(onClick = { onStatus(booking, "COMPLETED") }) { Text("Complete", color = Good) }
                            TextButton(onClick = { onStatus(booking, "CANCELLED") }) { Text("إلغاء", color = Color(0xFFFF7777)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BookingCard(booking: Booking, onEdit: (Booking) -> Unit, onDelete: (Booking) -> Unit, onFinance: (Booking) -> Unit, onDuplicate: (Booking) -> Unit) {
    val context = LocalContext.current
    var confirmDelete by remember(booking.id) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).border(1.dp, Purple.copy(alpha = .18f), RoundedCornerShape(20.dp)).padding(15.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(booking.customerName, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("${booking.teamOne.ifBlank { "Team 1" }}  ×  ${booking.teamTwo.ifBlank { "Team 2" }}", color = Muted, fontSize = 12.sp)
            }
            StatusPill(booking.status)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${booking.date} • ${booking.startTime} - ${booking.endTime}", color = Gold, fontSize = 12.sp)
            Text("${money(booking.total)} IQD", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        if (booking.matchType == "TOURNAMENT" || booking.matchType == "بطولة") Text("${booking.tournamentName} • ${booking.tournamentStage}", color = Purple, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("المدفوع: ${money(booking.paid)}  |  Due: ${money(booking.remaining)} IQD", color = Muted, fontSize = 11.sp)
            Row {
                IconButton(onClick = { onFinance(booking) }) { Icon(Icons.Default.Payments, "المدفوعات", tint = Good) }
                IconButton(onClick = { onEdit(booking) }) { Icon(Icons.Default.Edit, "تعديل", tint = Gold) }
                IconButton(onClick = { onDuplicate(booking) }) { Icon(Icons.Default.Add, "نسخ الحجز", tint = Purple) }
                IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFFFF7777)) }
                IconButton(onClick = { openWhatsApp(context, booking) }) { Text("WA", color = Good, fontWeight = FontWeight.Black, fontSize = 13.sp) }
            }
        }
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, containerColor = Panel, title = { Text("حذف الحجز؟") }, text = { Text("سيتم حذف الحجز وسجل دفعاته نهائياً.") }, confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete(booking) }) { Text("حذف", color = Color(0xFFFF7777)) } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("الاحتفاظ بالحجز", color = Muted) } })
}

@Composable
private fun PaymentLedgerDialog(
    booking: Booking,
    paymentDao: PaymentDao,
    onDismiss: () -> Unit,
    onEntry: (Long, Boolean, String, String) -> Unit
) {
    val entries by paymentDao.observeForBooking(booking.id).collectAsStateWithLifecycle(initialValue = emptyList())
    var amount by remember { mutableStateOf("") }
    var refund by remember { mutableStateOf(false) }
    var method by remember { mutableStateOf("CASH") }
    var note by remember { mutableStateOf("") }
    val net = entries.sumOf { if (it.kind == "REFUND") -it.amount else it.amount }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Payment ledger • ${booking.customerName}", color = Color.White) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Total ${money(booking.total)}  •  Collected ${money(net)}  •  Due ${money((booking.total - net).coerceAtLeast(0))}", color = Gold, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = !refund, onClick = { refund = false }, label = { Text("Payment") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = refund, onClick = { refund = true }, label = { Text("Refund") })
                }
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Amount (IQD)") }, singleLine = true)
                OutlinedTextField(method, { method = it }, label = { Text("Method (CASH / TRANSFER)") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, singleLine = true)
                Text("TRANSACTIONS", color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                if (entries.isEmpty()) Text("No transactions recorded", color = Muted, fontSize = 12.sp)
                entries.take(5).forEach { entry ->
                    Text("${entry.kind}  ${money(entry.amount)}  •  ${entry.method}", color = if (entry.kind == "REFUND") Color(0xFFFF8888) else Good, fontSize = 12.sp)
                }
            }
        },
        confirmButton = { TextButton(onClick = { amount.toLongOrNull()?.takeIf { it > 0 }?.let { onEntry(it, refund, method.ifBlank { "CASH" }, note) } }) { Text("Save entry", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = Muted) } }
    )
}

@Composable
private fun StatusPill(status: String) {
    val color = when (status) { "CONFIRMED", "مؤكد", "COMPLETED", "مكتمل" -> Good; "CANCELLED", "ملغي" -> Color(0xFFFF7777); else -> Gold }
    val label = when (status) { "CONFIRMED", "مؤكد" -> "Confirmed"; "CANCELLED", "ملغي" -> "Cancelled"; "PENDING", "بانتظار التأكيد" -> "Pending"; "COMPLETED", "مكتمل" -> "Completed"; else -> status }
    Text(label, color = color, fontSize = 10.sp, modifier = Modifier.clip(CircleShape).background(color.copy(alpha = .12f)).padding(horizontal = 10.dp, vertical = 5.dp))
}

@Composable
private fun FinanceScreen(bookings: List<Booking>, modifier: Modifier) {
    val valid = bookings.filter { it.status != "ملغي" && it.status != "CANCELLED" }
    val total = valid.sumOf { it.total }
    val paid = valid.sumOf { it.paid }
    val remaining = valid.sumOf { it.remaining }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Finance", fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 25.dp, bottom = 20.dp))
        FinanceTile("Total booking value", total, Gold)
        FinanceTile("Collected", paid, Good)
        FinanceTile("Outstanding", remaining, Purple)
        Spacer(Modifier.height(12.dp))
        Text("Financial totals are calculated from locally stored bookings.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun FinanceTile(title: String, amount: Long, color: Color) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Muted, fontSize = 13.sp)
        Text("${money(amount)} IQD", color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.CalendarMonth, null, tint = Purple, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun BookingEditor(initial: Booking?, onDismiss: () -> Unit, onSave: (Booking) -> Unit, onSaveRecurring: (Booking, String, String, Int) -> Unit) {
    val today = LocalDate.now().toString()
    var name by remember(initial) { mutableStateOf(initial?.customerName.orEmpty()) }
    var phone by remember(initial) { mutableStateOf(initial?.phone.orEmpty()) }
    var date by remember(initial) { mutableStateOf(initial?.date ?: today) }
    var start by remember(initial) { mutableStateOf(initial?.startTime ?: "19:00") }
    var end by remember(initial) { mutableStateOf(initial?.endTime ?: "20:00") }
    var team1 by remember(initial) { mutableStateOf(initial?.teamOne.orEmpty()) }
    var team2 by remember(initial) { mutableStateOf(initial?.teamTwo.orEmpty()) }
    var price by remember(initial) { mutableStateOf(initial?.pricePerTeam?.toString() ?: "6000") }
    var paid by remember(initial) { mutableStateOf(initial?.paid?.toString() ?: "0") }
    var matchType by remember(initial) { mutableStateOf(if (initial?.matchType == "بطولة" || initial?.matchType == "TOURNAMENT") "TOURNAMENT" else "FRIENDLY") }
    var tournament by remember(initial) { mutableStateOf(initial?.tournamentName.orEmpty()) }
    var stage by remember(initial) { mutableStateOf(initial?.tournamentStage ?: "مرحلة المجموعات") }
    var notes by remember(initial) { mutableStateOf(initial?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    var repeat by remember { mutableStateOf(false) }
    var frequency by remember { mutableStateOf("WEEKLY") }
    var untilDate by remember { mutableStateOf(LocalDate.now().plusMonths(1).toString()) }
    var occurrenceCount by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel2,
        title = { Text(if (initial == null) "New booking" else "Edit booking", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item { FormField("اسم العميل", name, { name = it }) }
                item { FormField("رقم الهاتف", phone, { phone = it }, KeyboardType.Phone) }
                item { FormField("التاريخ (سنة-شهر-يوم)", date, { date = it }) }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { FormField("وقت البداية", start, { start = it }) }; Box(Modifier.weight(1f)) { FormField("وقت النهاية", end, { end = it }) } } }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.weight(1f)) { FormField("الفريق الأول", team1, { team1 = it }) }; Box(Modifier.weight(1f)) { FormField("الفريق الثاني", team2, { team2 = it }) } } }
                item { FormField("السعر لكل فريق (د.ع)", price, { price = it }, KeyboardType.Number) }
                if (initial == null) item { FormField("الدفعة الأولى (د.ع)", paid, { paid = it }, KeyboardType.Number) }
                else item { Text("Manage payments and refunds from the Payments button on this booking.", color = Muted, fontSize = 11.sp) }
                item { Text("نوع الحجز", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("FRIENDLY" to "ودية", "TOURNAMENT" to "بطولة").forEach { (v, label) -> FilterChip(selected = matchType == v, onClick = { matchType = v }, label = { Text(label) }) } } }
                if (matchType == "TOURNAMENT") {
                    item { FormField("اسم البطولة", tournament, { tournament = it }) }
                    item { Text("Stage", color = Gold, fontSize = 12.sp) }
                    item { Column { listOf("مرحلة المجموعات", "ربع النهائي", "نصف النهائي", "النهائي").forEach { v -> Row(Modifier.fillMaxWidth().clickable { stage = v }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = stage == v, onClick = { stage = v }, colors = RadioButtonDefaults.colors(selectedColor = Gold)); Text(v, fontSize = 13.sp) } } } }
                }
                item { FormField("ملاحظات", notes, { notes = it }) }
                if (initial == null) {
                    item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(repeat, { repeat = it }); Text("تكرار هذا الحجز", color = Gold) } }
                    if (repeat) {
                        item { Text("تكرار الحجز", color = Gold, fontSize = 12.sp) }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("DAILY" to "يومي", "WEEKLY" to "أسبوعي", "MONTHLY" to "شهري", "WEEKDAYS" to "أيام العمل").forEach { (f, label) -> FilterChip(selected = frequency == f, onClick = { frequency = f }, label = { Text(label) }) } } }
                        item { FormField("تاريخ انتهاء التكرار", untilDate, { untilDate = it }) }
                        item { FormField("عدد التكرارات (0 حتى تاريخ الانتهاء)", occurrenceCount, { occurrenceCount = it }, KeyboardType.Number) }
                    }
                }
                if (error != null) item { Text(error!!, color = Color(0xFFFF7777), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val startM = parseMinutes(start); val endM = parseMinutes(end)
                val p = price.toLongOrNull(); val pay = paid.toLongOrNull()
                error = when {
                    name.isBlank() -> "أدخل اسم العميل"
                    phone.isBlank() -> "أدخل رقم الهاتف"
                    runCatching { LocalDate.parse(date) }.isFailure -> "صيغة التاريخ غير صحيحة"
                    startM == null || endM == null || endM <= startM -> "تحقق من وقت البداية والنهاية"
                    p == null || p < 0 || p > Long.MAX_VALUE / 2 || pay == null || pay < 0 -> "تحقق من المبالغ"
                    pay > p * 2 -> "Initial payment exceeds the booking total"
                    matchType == "TOURNAMENT" && tournament.isBlank() -> "أدخل اسم البطولة"
                    else -> null
                }
                if (error == null) {
                    val booking = Booking(
                    id = initial?.id ?: 0, customerName = name.trim(), phone = phone.trim(), date = date,
                    startTime = start, endTime = end, startMinutes = startM!!, endMinutes = endM!!,
                    teamOne = team1.trim(), teamTwo = team2.trim(), pricePerTeam = p!!, paid = pay!!,
                    matchType = matchType, tournamentName = if (matchType == "TOURNAMENT") tournament.trim() else "",
                    tournamentStage = if (matchType == "TOURNAMENT") stage else "", notes = notes.trim(),
                    status = initial?.status ?: "مؤكد", createdAt = initial?.createdAt ?: System.currentTimeMillis()
                    )
                    if (repeat && initial == null) {
                        val count = occurrenceCount.toIntOrNull()
                        error = when { runCatching { LocalDate.parse(untilDate) }.isFailure -> "Invalid repeat-until date"; count == null || count < 0 -> "Invalid occurrence count"; else -> null }
                        if (error == null) onSaveRecurring(booking, frequency, untilDate, count!!)
                    } else onSave(booking)
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Muted) } }
    )
}

@Composable
private fun FormField(label: String, value: String, onValue: (String) -> Unit, keyboard: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label, fontSize = 11.sp) }, singleLine = true, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = keyboard), colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF51465E), focusedLabelColor = Gold,
        cursorColor = Gold, focusedTextColor = Color.White, unfocusedTextColor = Color.White
    ))
}

internal fun parseMinutes(value: String): Int? = runCatching {
    require(value.matches(Regex("\\d{2}:\\d{2}")))
    val parts = value.split(":")
    require(parts.size == 2)
    val h = parts[0].toInt(); val m = parts[1].toInt()
    require(h in 0..23 && m in 0..59)
    h * 60 + m
}.getOrNull()

private fun money(value: Long): String = String.format("%,d", value).replace(",", "٬")

private fun openWhatsApp(context: android.content.Context, booking: Booking) {
    val phone = booking.phone.filter { it.isDigit() || it == '+' }.replace("+", "")
    val defaultTemplate = "مرحباً {name}، تم تأكيد حجزكم بتاريخ {date} من {start} إلى {end}.\nالإجمالي: {total} د.ع\nالمدفوع: {paid} د.ع\nالمتبقي: {due} د.ع\n{tournament}"
    val template = context.getSharedPreferences("hjoozati_preferences", android.content.Context.MODE_PRIVATE).getString("whatsapp_template", defaultTemplate) ?: defaultTemplate
    val message = template
        .replace("{name}", booking.customerName)
        .replace("{date}", booking.date)
        .replace("{start}", booking.startTime)
        .replace("{end}", booking.endTime)
        .replace("{total}", money(booking.total))
        .replace("{paid}", money(booking.paid))
        .replace("{due}", money(booking.remaining))
        .replace("{tournament}", if (booking.matchType == "TOURNAMENT" || booking.matchType == "بطولة") "البطولة: ${booking.tournamentName} • المرحلة: ${booking.tournamentStage}" else "")
    val url = "https://wa.me/$phone?text=" + URLEncoder.encode(message, "UTF-8")
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
