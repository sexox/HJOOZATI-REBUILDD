package com.hjoozati.app.data

import androidx.room.withTransaction

/** Keeps the payment ledger and the legacy Booking.paid compatibility field in sync atomically. */
class BookingFinanceRepository(private val database: AppDatabase) {
    suspend fun recordPayment(bookingId: Long, amount: Long, method: String = "CASH", note: String = ""): Long =
        record(bookingId, amount, BookingFinance.EntryKind.PAYMENT, method, note)

    suspend fun recordRefund(bookingId: Long, amount: Long, method: String = "CASH", note: String = ""): Long =
        record(bookingId, amount, BookingFinance.EntryKind.REFUND, method, note)

    private suspend fun record(
        bookingId: Long,
        amount: Long,
        kind: BookingFinance.EntryKind,
        method: String,
        note: String
    ): Long = database.withTransaction {
        val booking = database.bookingDao().getById(bookingId)
            ?: throw IllegalArgumentException("Booking not found")
        val currentNet = database.paymentDao().netPaid(bookingId)
        BookingFinance.validateEntry(kind, amount, currentNet, booking.total)
        val nextNet = BookingFinance.applyNet(currentNet, kind, amount)
        val rowId = database.paymentDao().insert(
            Payment(
                bookingId = bookingId,
                amount = amount,
                kind = kind.name,
                method = method,
                note = note.trim()
            )
        )
        database.bookingDao().update(booking.copy(paid = nextNet))
        rowId
    }

    suspend fun removeBookingAndLedger(bookingId: Long) = database.withTransaction {
        database.paymentDao().deleteForBooking(bookingId)
        database.recurringRuleDao().deleteForBooking(bookingId)
        database.bookingDao().getById(bookingId)?.let { database.bookingDao().delete(it) }
    }
}
