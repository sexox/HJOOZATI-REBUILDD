package com.hjoozati.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE bookingId = :bookingId ORDER BY paidAt DESC")
    fun observeForBooking(bookingId: Long): Flow<List<Payment>>
    @Query("SELECT * FROM payments ORDER BY paidAt DESC") fun observeAll(): Flow<List<Payment>>
    @Query("SELECT * FROM payments WHERE bookingId = :bookingId ORDER BY paidAt DESC")
    suspend fun getForBooking(bookingId: Long): List<Payment>
    @Query("SELECT * FROM payments ORDER BY id") suspend fun getAllSnapshot(): List<Payment>
    @Query("DELETE FROM payments") suspend fun clearAll()
    @Query("SELECT COALESCE(SUM(CASE WHEN kind = 'REFUND' THEN -amount ELSE amount END), 0) FROM payments WHERE bookingId = :bookingId")
    suspend fun netPaid(bookingId: Long): Long
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(payment: Payment): Long
    @Query("DELETE FROM payments WHERE bookingId = :bookingId") suspend fun deleteForBooking(bookingId: Long)
}

@Dao
interface TournamentDao {
    @Query("SELECT * FROM tournaments ORDER BY startDate DESC") fun observeAll(): Flow<List<Tournament>>
    @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1") suspend fun get(id: Long): Tournament?
    @Query("SELECT * FROM tournaments ORDER BY id") suspend fun getAllSnapshot(): List<Tournament>
    @Query("DELETE FROM tournaments") suspend fun clearAll()
    @Insert suspend fun insert(tournament: Tournament): Long
    @Update suspend fun update(tournament: Tournament)
    @Query("DELETE FROM tournaments WHERE id = :id") suspend fun delete(id: Long)

    @Query("SELECT * FROM tournament_teams WHERE tournamentId = :tournamentId ORDER BY points DESC, (goalsFor - goalsAgainst) DESC, goalsFor DESC")
    fun observeTeams(tournamentId: Long): Flow<List<TournamentTeam>>
    @Query("SELECT * FROM tournament_teams ORDER BY name") fun observeAllTeams(): Flow<List<TournamentTeam>>
    @Query("SELECT * FROM tournament_teams ORDER BY id") suspend fun getAllTeamsSnapshot(): List<TournamentTeam>
    @Query("DELETE FROM tournament_teams") suspend fun clearAllTeams()
    @Insert suspend fun insertTeam(team: TournamentTeam): Long
    @Update suspend fun updateTeam(team: TournamentTeam)
    @Query("DELETE FROM tournament_teams WHERE tournamentId = :tournamentId") suspend fun deleteTeams(tournamentId: Long)

    @Query("SELECT * FROM tournament_matches WHERE tournamentId = :tournamentId ORDER BY matchDate, startTime")
    fun observeMatches(tournamentId: Long): Flow<List<TournamentMatch>>
    @Query("SELECT * FROM tournament_matches ORDER BY matchDate, startTime") fun observeAllMatches(): Flow<List<TournamentMatch>>
    /** Tournament fixtures reserve one 60-minute slot on the same venue resource. */
    @Query("SELECT * FROM tournament_matches WHERE matchDate = :date AND time(startTime) < time(:endTime) AND time(startTime, '+60 minutes') > time(:startTime) LIMIT 1")
    suspend fun findMatchOverlap(date: String, startTime: String, endTime: String): TournamentMatch?
    @Query("SELECT * FROM tournament_matches ORDER BY id") suspend fun getAllMatchesSnapshot(): List<TournamentMatch>
    @Query("DELETE FROM tournament_matches") suspend fun clearAllMatches()
    @Insert suspend fun insertMatch(match: TournamentMatch): Long
    @Update suspend fun updateMatch(match: TournamentMatch)
    @Query("DELETE FROM tournament_matches WHERE tournamentId = :tournamentId") suspend fun deleteMatches(tournamentId: Long)
}

@Dao
interface RecurringRuleDao {
    @Query("SELECT * FROM recurring_rules WHERE active = 1") fun observeActive(): Flow<List<RecurringRule>>
    @Query("SELECT * FROM recurring_rules WHERE bookingId = :bookingId LIMIT 1") suspend fun forBooking(bookingId: Long): RecurringRule?
    @Query("SELECT * FROM recurring_rules ORDER BY id") suspend fun getAllSnapshot(): List<RecurringRule>
    @Query("DELETE FROM recurring_rules") suspend fun clearAll()
    @Insert suspend fun insert(rule: RecurringRule): Long
    @Update suspend fun update(rule: RecurringRule)
    @Query("UPDATE recurring_rules SET active = 0 WHERE bookingId = :bookingId") suspend fun deactivateForBooking(bookingId: Long)
    @Query("DELETE FROM recurring_rules WHERE bookingId = :bookingId") suspend fun deleteForBooking(bookingId: Long)
}

@Dao
interface AppSettingDao {
    @Query("SELECT * FROM app_settings") fun observeAll(): Flow<List<AppSetting>>
    @Query("SELECT * FROM app_settings ORDER BY settingKey") suspend fun getAllSnapshot(): List<AppSetting>
    @Query("DELETE FROM app_settings") suspend fun clearAll()
    @Query("SELECT value FROM app_settings WHERE settingKey = :key LIMIT 1") suspend fun get(key: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(setting: AppSetting)
}

@Dao
interface ImportantEventDao {
    @Query("SELECT * FROM important_events ORDER BY date, time") fun observeAll(): Flow<List<ImportantEvent>>
    @Query("SELECT * FROM important_events ORDER BY id") suspend fun getAllSnapshot(): List<ImportantEvent>
    @Insert suspend fun insert(event: ImportantEvent): Long
    @Update suspend fun update(event: ImportantEvent)
    @Query("DELETE FROM important_events WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM important_events") suspend fun clearAll()
}
