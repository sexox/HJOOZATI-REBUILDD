package com.hjoozati.app.data

import java.time.DayOfWeek
import java.time.LocalDate

object BookingRules {
    enum class PaymentState { UNPAID, PARTIAL, PAID, REFUND_DUE }

    fun paymentState(total: Long, netPaid: Long): PaymentState = when {
        netPaid < 0 -> PaymentState.REFUND_DUE
        netPaid == 0L -> PaymentState.UNPAID
        netPaid < total -> PaymentState.PARTIAL
        else -> PaymentState.PAID
    }

    fun balance(total: Long, netPaid: Long): Long = (total - netPaid).coerceAtLeast(0)

    /** Generates dates inclusively. Weekday values use ISO-8601: Monday=1 ... Sunday=7. */
    fun occurrences(
        start: LocalDate,
        frequency: String,
        interval: Int = 1,
        weekdays: Set<Int> = emptySet(),
        until: LocalDate? = null,
        count: Int = 0,
        maxOccurrences: Int = 500
    ): List<LocalDate> {
        require(interval >= 1) { "interval must be at least 1" }
        require(count >= 0) { "count cannot be negative" }
        val limitDate = until ?: start.plusYears(5)
        require(!limitDate.isBefore(start)) { "until date precedes start date" }
        val out = mutableListOf<LocalDate>()
        var day = start
        while (!day.isAfter(limitDate) && out.size < maxOccurrences && (count == 0 || out.size < count)) {
            val include = when (frequency.uppercase()) {
                "DAILY" -> java.time.temporal.ChronoUnit.DAYS.between(start, day) % interval == 0L
                "WEEKLY" -> {
                    val firstWeek = start.with(java.time.temporal.TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                    val candidateWeek = day.with(java.time.temporal.TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                    val weeks = java.time.temporal.ChronoUnit.WEEKS.between(firstWeek, candidateWeek)
                    val selectedDay = if (weekdays.isEmpty()) day.dayOfWeek == start.dayOfWeek else day.dayOfWeek.value in weekdays
                    weeks % interval == 0L && selectedDay
                }
                "MONTHLY" -> {
                    val months = java.time.temporal.ChronoUnit.MONTHS.between(start.withDayOfMonth(1), day.withDayOfMonth(1))
                    months % interval == 0L && day.dayOfMonth == start.dayOfMonth
                }
                "WEEKDAYS" -> day.dayOfWeek in setOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)
                else -> throw IllegalArgumentException("Unsupported frequency: $frequency")
            }
            if (include) out += day
            day = day.plusDays(1)
        }
        return out
    }

    fun hasTimeConflict(startA: Int, endA: Int, startB: Int, endB: Int): Boolean {
        require(startA in 0..1439 && endA in 1..1440 && startA < endA) { "Invalid first time range" }
        require(startB in 0..1439 && endB in 1..1440 && startB < endB) { "Invalid second time range" }
        return startA < endB && endA > startB
    }
    data class MatchResult(val homeTeamId: Long, val awayTeamId: Long, val homeScore: Int, val awayScore: Int)
    data class Standing(val teamId: Long, val played: Int, val won: Int, val drawn: Int, val lost: Int, val goalsFor: Int, val goalsAgainst: Int, val points: Int) {
        val goalDifference: Int get() = goalsFor - goalsAgainst
    }

    /** Calculates a deterministic league table from completed match results. */
    fun standings(teamIds: Collection<Long>, matches: Collection<MatchResult>): List<Standing> {
        require(teamIds.distinct().size == teamIds.size) { "Duplicate team id" }
        val rows = teamIds.associateWith { longArrayOf(0, 0, 0, 0, 0, 0, 0) }.toMutableMap()
        matches.forEach { m ->
            require(m.homeTeamId != m.awayTeamId && m.homeScore >= 0 && m.awayScore >= 0) { "Invalid match result" }
            require(rows.containsKey(m.homeTeamId) && rows.containsKey(m.awayTeamId)) { "Unknown team" }
            val h = rows.getValue(m.homeTeamId); val a = rows.getValue(m.awayTeamId)
            h[0]++; a[0]++
            h[4] += m.homeScore.toLong(); h[5] += m.awayScore.toLong()
            a[4] += m.awayScore.toLong(); a[5] += m.homeScore.toLong()
            when {
                m.homeScore > m.awayScore -> { h[1]++; h[6] += 3L; a[3]++ }
                m.homeScore < m.awayScore -> { a[1]++; a[6] += 3L; h[3]++ }
                else -> { h[2]++; a[2]++; h[6]++; a[6]++ }
            }
        }
        return rows.map { (id, r) -> Standing(id, r[0].toInt(), r[1].toInt(), r[2].toInt(), r[3].toInt(), r[4].toInt(), r[5].toInt(), r[6].toInt()) }
            .sortedWith(compareByDescending<Standing> { it.points }.thenByDescending { it.goalDifference }.thenByDescending { it.goalsFor }.thenBy { it.teamId })
    }

    /** Rejects a recurring series atomically if any generated occurrence overlaps an existing booking. */
    fun recurringConflictDates(
        dates: List<LocalDate>, startMinutes: Int, endMinutes: Int,
        existing: Map<LocalDate, List<IntRange>>
    ): List<LocalDate> {
        require(startMinutes in 0..1439 && endMinutes in 1..1440 && startMinutes < endMinutes)
        return dates.filter { date -> existing[date].orEmpty().any { range -> startMinutes < range.last + 1 && endMinutes > range.first } }
    }

}
