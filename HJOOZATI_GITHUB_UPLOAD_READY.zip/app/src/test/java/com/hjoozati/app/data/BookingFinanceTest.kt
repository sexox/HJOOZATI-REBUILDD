package com.hjoozati.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class BookingFinanceTest {
    @Test fun paymentAndRefundKeepNetBalanceConsistent() {
        val afterPayment = BookingFinance.applyNet(0, BookingFinance.EntryKind.PAYMENT, 700)
        val afterRefund = BookingFinance.applyNet(afterPayment, BookingFinance.EntryKind.REFUND, 200)
        assertEquals(700L, afterPayment)
        assertEquals(500L, afterRefund)
        val summary = BookingFinance.summarize(1_000, afterRefund)
        assertEquals(500L, summary.collected)
        assertEquals(500L, summary.outstanding)
        assertEquals(BookingRules.PaymentState.PARTIAL, summary.state)
    }

    @Test fun rejectPaymentAboveTotal() {
        assertThrows(IllegalArgumentException::class.java) {
            BookingFinance.validateEntry(BookingFinance.EntryKind.PAYMENT, 501, 500, 1_000)
        }
    }

    @Test fun rejectRefundAboveCollected() {
        assertThrows(IllegalArgumentException::class.java) {
            BookingFinance.validateEntry(BookingFinance.EntryKind.REFUND, 501, 500, 1_000)
        }
    }

    @Test fun arithmeticOverflowIsRejected() {
        assertThrows(ArithmeticException::class.java) {
            BookingFinance.validateEntry(BookingFinance.EntryKind.PAYMENT, Long.MAX_VALUE, 1, Long.MAX_VALUE)
        }
    }

    @Test fun zeroAndNegativeEntriesAreRejected() {
        assertThrows(IllegalArgumentException::class.java) {
            BookingFinance.applyNet(0, BookingFinance.EntryKind.PAYMENT, 0)
        }
        assertThrows(IllegalArgumentException::class.java) {
            BookingFinance.applyNet(0, BookingFinance.EntryKind.REFUND, -1)
        }
    }
}
