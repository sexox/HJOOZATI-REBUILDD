package com.hjoozati.app.data

import org.junit.Assert.*
import org.junit.Test

class TournamentRulesTest {
    @Test fun leagueTableRanksWinsDrawsAndGoalDifference() {
        val table = BookingRules.standings(listOf(1L, 2L, 3L), listOf(
            BookingRules.MatchResult(1, 2, 2, 0),
            BookingRules.MatchResult(2, 3, 1, 1),
            BookingRules.MatchResult(3, 1, 0, 1)
        ))
        assertEquals(1L, table.first().teamId)
        assertEquals(6, table.first().points)
        assertEquals(2, table.first().won)
        assertEquals(1, table.last().drawn)
    }

    @Test fun rejectsInvalidMatchTeamsAndScores() {
        assertThrows(IllegalArgumentException::class.java) {
            BookingRules.standings(listOf(1L, 2L), listOf(BookingRules.MatchResult(1, 1, 2, 0)))
        }
        assertThrows(IllegalArgumentException::class.java) {
            BookingRules.standings(listOf(1L, 2L), listOf(BookingRules.MatchResult(1, 2, -1, 0)))
        }
    }
}
