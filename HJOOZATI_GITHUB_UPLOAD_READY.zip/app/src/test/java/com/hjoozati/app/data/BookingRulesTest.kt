package com.hjoozati.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class BookingRulesTest {
    @Test fun paymentStatesCoverUnpaidPartialPaidAndRefundDue() {
        assertEquals(BookingRules.PaymentState.UNPAID, BookingRules.paymentState(100, 0))
        assertEquals(BookingRules.PaymentState.PARTIAL, BookingRules.paymentState(100, 40))
        assertEquals(BookingRules.PaymentState.PAID, BookingRules.paymentState(100, 100))
        assertEquals(BookingRules.PaymentState.REFUND_DUE, BookingRules.paymentState(100, -10))
    }

    @Test fun balanceNeverGoesBelowZero() {
        assertEquals(60L, BookingRules.balance(100, 40))
        assertEquals(0L, BookingRules.balance(100, 120))
    }

    @Test fun timeRangesOnlyConflictWhenTheyOverlap() {
        assertTrue(BookingRules.hasTimeConflict(600, 720, 700, 780))
        assertFalse(BookingRules.hasTimeConflict(600, 700, 700, 800))
    }

    @Test fun dailyRecurrenceRespectsIntervalAndCount() {
        val dates = BookingRules.occurrences(LocalDate.parse("2026-11-01"), "DAILY", interval = 2, count = 3)
        assertEquals(listOf("2026-11-01", "2026-11-03", "2026-11-05"), dates.map { it.toString() })
    }

    @Test fun weekdayRecurrenceUsesIsoWeekdays() {
        val dates = BookingRules.occurrences(
            LocalDate.parse("2026-11-09"), "WEEKLY", weekdays = setOf(1, 3), until = LocalDate.parse("2026-11-16")
        )
        assertEquals(listOf("2026-11-09", "2026-11-11", "2026-11-16"), dates.map { it.toString() })
    }

    @Test fun weeklyRecurrenceWithoutWeekdaySelectionRepeatsOnStartWeekday() {
        val dates = BookingRules.occurrences(
            LocalDate.parse("2026-11-11"), "WEEKLY", until = LocalDate.parse("2026-11-25")
        )
        assertEquals(listOf("2026-11-11", "2026-11-18", "2026-11-25"), dates.map { it.toString() })
    }

    @Test fun monthlyRecurrenceSkipsMonthsWithoutTheStartDay() {
        val dates = BookingRules.occurrences(LocalDate.parse("2026-01-31"), "MONTHLY", until = LocalDate.parse("2026-04-30"))
        assertEquals(listOf("2026-01-31", "2026-03-31"), dates.map { it.toString() })
    }
}
