package com.hjoozati.app.data

import org.junit.Assert.*
import org.junit.Test

class TournamentFixturesTest {
    @Test fun roundRobinCoversEveryPairOnceForEvenTeams() {
        val fixtures = TournamentFixtures.roundRobin(listOf(1, 2, 3, 4).map(Int::toLong))
        assertEquals(6, fixtures.size)
        assertEquals(6, fixtures.map { setOf(it.home, it.away) }.toSet().size)
    }

    @Test fun roundRobinHandlesOddTeamBye() {
        val fixtures = TournamentFixtures.roundRobin(listOf(1, 2, 3, 4, 5).map(Int::toLong))
        assertEquals(10, fixtures.size)
        assertEquals(5, fixtures.map { it.round }.toSet().size)
    }

    @Test fun knockoutPairsSeedsFromOutsideIn() {
        assertEquals(listOf(1L to 4L, 2L to 3L), TournamentFixtures.knockoutFirstRound(listOf(1, 2, 3, 4).map(Int::toLong)).map { it.home to it.away })
    }

    @Test fun knockoutRejectsUnevenFieldToAvoidSilentByes() {
        assertThrows(IllegalArgumentException::class.java) { TournamentFixtures.knockoutFirstRound(listOf(1L, 2L, 3L)) }
    }

    @Test fun twoGroupTopTeamsAdvanceToCrossSemiFinals() {
        val teams = listOf(
            TournamentTeam(id = 1, tournamentId = 1, name = "A1", groupName = "A"),
            TournamentTeam(id = 2, tournamentId = 1, name = "A2", groupName = "A"),
            TournamentTeam(id = 3, tournamentId = 1, name = "B1", groupName = "B"),
            TournamentTeam(id = 4, tournamentId = 1, name = "B2", groupName = "B")
        )
        val matches = listOf(
            TournamentMatch(tournamentId = 1, homeTeamId = 1, awayTeamId = 2, matchDate = "2026-11-13", homeScore = 2, awayScore = 0, roundName = "Group stage • Round 1"),
            TournamentMatch(tournamentId = 1, homeTeamId = 3, awayTeamId = 4, matchDate = "2026-11-13", homeScore = 1, awayScore = 0, roundName = "Group stage • Round 1")
        )
        val semis = TournamentFixtures.groupSemiFinals(teams, matches)
        assertEquals(2, semis.size)
        assertEquals(setOf(1L, 3L), semis.map { it.home }.toSet())
    }

    @Test fun completedKnockoutRoundAdvancesWinners() {
        val matches = listOf(
            TournamentMatch(tournamentId = 1, homeTeamId = 1, awayTeamId = 4, matchDate = "2026-11-13", homeScore = 2, awayScore = 0, roundName = "Knockout Round 1"),
            TournamentMatch(tournamentId = 1, homeTeamId = 2, awayTeamId = 3, matchDate = "2026-11-13", homeScore = 1, awayScore = 0, roundName = "Knockout Round 1")
        )
        val next = TournamentFixtures.nextKnockoutRound(matches)
        assertEquals(listOf(1L to 2L), next.map { it.home to it.away })
        assertEquals(2, next.single().round)
    }
}
