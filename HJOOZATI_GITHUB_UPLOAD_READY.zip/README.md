# HJOOZATI

Android app for managing venue bookings, payment history, tournaments and schedules.

## Project configuration

- Application ID: `com.hjoozati.app`
- Minimum Android: API 26
- Compile / target SDK: 35
- Kotlin / Java bytecode target: 17
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Local Room database; no login, cloud sync or server required
- Manual WhatsApp handoff only; the owner must press Send
- Android automatic backup disabled; explicit offline JSON backup/restore is provided

## Current features in source

- Room v3 database with automatic v1→v2→v3 migrations.

- Booking CRUD, status actions, conflict checks, search and status filters.
- Payment/refund ledger with atomic persistence and balance validation.
- Home totals for today and month, completed/cancelled bookings and outstanding balances.
- Day, week and month calendar views with important-event management.
- Recurring bookings (daily, weekly, monthly and weekdays) with per-date conflict preflight.
- Local reminders for bookings, unpaid balances, tournament start dates and user-created important events; configurable reminder lead time.
- JSON backup and restore for all local business data, with validation and explicit replacement confirmation.
- Tournament creation/editing, team/group management, manual match scheduling and score entry.
- Automatic league round-robin fixtures, knockout round progression, and two-group group-stage plus cross-group semi-final/final generation. Tournament fixtures reserve a 60-minute slot and are checked against ordinary bookings.
- Approved launcher logo and fixed purple, gold and black identity.

## Build

Requires JDK 17 and Gradle 8.9:

```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

A GitHub Actions workflow is included at `.github/workflows/android-build.yml` and uploads the debug APK artifact after a successful build and unit-test run.

## Release warning

This repository snapshot is still under development. The Android Gradle build, Room/KSP generated code, JUnit suite, APK installation and real-device tests have **not** been verified in the current environment (no Android SDK/Gradle installation and no network access to install them). See `IMPLEMENTATION_STATUS.md` for tested facts and remaining release gates. Do not treat this source ZIP as a verified APK or publish it as production-ready until those gates pass.

## Privacy and customer messaging

Business records stay in the app's local database unless the owner exports a backup file. WhatsApp only opens a prefilled chat; it never sends messages automatically.
