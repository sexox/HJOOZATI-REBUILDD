package com.hjoozati.app.data

import org.junit.Assert.*
import org.junit.Test

class BookingRulesTest {
    @Test fun adjacentBookingsDoNotOverlap() {
        assertFalse(BookingRules.overlaps(540, 600, 600, 660))
    }
    @Test fun intersectingBookingsOverlap() {
        assertTrue(BookingRules.overlaps(540, 620, 600, 660))
    }
    @Test fun invalidIntervalsAreRejected() {
        assertFalse(BookingRules.validInterval(600, 600))
        assertFalse(BookingRules.validInterval(700, 650))
        assertTrue(BookingRules.validInterval(540, 600))
    }
    @Test fun refundsReduceNetPaidWithoutNegativeBalance() {
        assertEquals(300L, BookingRules.balance(1000L, 700L))
        assertEquals(1000L, BookingRules.balance(1000L, -100L))
    }
}
