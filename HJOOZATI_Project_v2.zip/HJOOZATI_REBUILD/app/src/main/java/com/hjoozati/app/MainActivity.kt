package com.hjoozati.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.Manifest
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext
import androidx.room.Room
import com.google.gson.Gson
import com.hjoozati.app.data.*
import com.hjoozati.app.util.ReminderScheduler
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.net.URLEncoder

private val Ink = Color(0xFF090812)
private val Panel = Color(0xFF171426)
private val Purple = Color(0xFF8B5CF6)
private val Gold = Color(0xFFD9B66D)
private val Muted = Color(0xFFAAA4BA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = HjoDatabase.get(this)
        setContent { HjoApp(db.dao()) }
    }
}

private data class BackupBundle(val version: Int = 1, val bookings: List<Booking>, val payments: List<Payment>, val tournaments: List<Tournament>, val matches: List<TournamentMatch>)

@Composable private fun HjoApp(dao: HjoDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bookings by dao.bookings().collectAsState(initial = emptyList())
    val tournaments by dao.tournaments().collectAsState(initial = emptyList())
    var tab by remember { mutableStateOf("Home") }
    var showNew by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Booking?>(null) }
    var showTournament by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) { if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch { runCatching {
            val data = BackupBundle(bookings = dao.allBookings(), payments = dao.allPayments(), tournaments = dao.allTournaments(), matches = dao.allMatches())
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(Gson().toJson(data)) }
        }.onSuccess { toast = "Backup exported" }.onFailure { toast = "Backup failed: ${it.message}" } }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { runCatching {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Cannot read file")
            val type = object : com.google.gson.reflect.TypeToken<BackupBundle>() {}.type
            val data = Gson().fromJson<BackupBundle>(raw, type) ?: error("Invalid backup")
            require(data.bookings != null && data.payments != null && data.tournaments != null && data.matches != null) { "Invalid backup structure" }
            require(data.version == 1) { "Unsupported backup version" }
            dao.replaceAll(data.bookings, data.payments, data.tournaments, data.matches)
        }.onSuccess { toast = "Backup restored" }.onFailure { toast = "Restore failed: ${it.message}" } }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Purple, secondary = Gold, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Color(0xFF100D1B), contentColor = Gold) {
                listOf("Home" to Icons.Default.Home, "Bookings" to Icons.Default.CalendarMonth, "Tournaments" to Icons.Default.EmojiEvents, "Settings" to Icons.Default.Settings).forEach { (name, icon) ->
                    NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Icon(icon, null) }, label = { Text(name) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Purple.copy(alpha = .22f), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }, floatingActionButton = {
            if (tab == "Bookings") FloatingActionButton(onClick = { selected = null; showNew = true }, containerColor = Purple, contentColor = Color.White) { Icon(Icons.Default.Add, "New booking") }
            if (tab == "Tournaments") FloatingActionButton(onClick = { showTournament = true }, containerColor = Purple, contentColor = Color.White) { Icon(Icons.Default.Add, "New tournament") }
        }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    "Home" -> HomePage(bookings, dao, onBookings = { tab = "Bookings" })
                    "Bookings" -> BookingPage(bookings, dao, onEdit = { selected = it; showNew = true }, onMessage = { b ->
                        val msg = "Hello ${b.customerName}, this is a reminder about your booking for ${b.title} on ${b.date}."
                        val url = "https://wa.me/${b.phone.filter { it.isDigit() }}?text=${URLEncoder.encode(msg, "UTF-8")}"
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }.onFailure { toast = "WhatsApp is not available" }
                    })
                    "Tournaments" -> TournamentPage(tournaments, dao)
                    else -> SettingsPage(onExport = { exportLauncher.launch("hjoozati-backup-${LocalDate.now()}.json") }, onImport = { importLauncher.launch(arrayOf("application/json", "text/*")) })
                }
                if (toast.isNotBlank()) {
                    LaunchedEffect(toast) { kotlinx.coroutines.delay(2500); toast = "" }
                    Surface(Modifier.align(Alignment.BottomCenter).padding(16.dp), color = Purple, shape = RoundedCornerShape(14.dp)) { Text(toast, Modifier.padding(14.dp), color = Color.White) }
                }
            }
        }
        if (showNew) BookingDialog(selected, onDismiss = { showNew = false }, onSave = { item, count, frequency ->
            scope.launch {
                val baseId = item.id
                val dates = recurrenceDates(item.date, count, frequency)
                var conflict = false
                for (date in dates) {
                    val existing = dao.activeOn(date).filter { it.id != baseId && it.resource.equals(item.resource, true) }
                    if (existing.any { BookingRules.overlaps(item.startMinute, item.endMinute, it.startMinute, it.endMinute) }) { conflict = true; break }
                }
                if (conflict) toast = "Conflict: resource already booked at this time"
                else {
                    if (baseId == 0L) dates.forEach { date -> val newId = dao.addBooking(item.copy(date = date)); ReminderScheduler.schedule(context, newId, item.title, date, item.startMinute) } else { dao.updateBooking(item); ReminderScheduler.schedule(context, item.id, item.title, item.date, item.startMinute) }
                    toast = if (dates.size > 1) "${dates.size} bookings created" else "Booking saved"
                    showNew = false
                }
            }
        })
        if (showTournament) TournamentDialog(onDismiss = { showTournament = false }, onSave = { t -> scope.launch { dao.addTournament(t); showTournament = false; toast = "Tournament created" } })
    }
}

private fun recurrenceDates(start: String, count: Int, frequency: String): List<String> {
    val first = LocalDate.parse(start)
    return (0 until count.coerceIn(1, 52)).map { i ->
        val date = when (frequency) {
            "Daily" -> first.plusDays(i.toLong())
            "Weekly" -> first.plusWeeks(i.toLong())
            "Monthly" -> first.plusMonths(i.toLong())
            "Weekdays" -> {
                var candidate = first
                var weekdaysSeen = 0
                while (weekdaysSeen < i + 1) {
                    if (candidate.dayOfWeek.value <= 5) weekdaysSeen++
                    if (weekdaysSeen < i + 1) candidate = candidate.plusDays(1)
                }
                candidate
            }
            else -> first
        }
        date.toString()
    }.distinct()
}

@Composable private fun PageHeader(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("HJOOZATI", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 13.sp)
    }
}
@Composable private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF211B35), Panel.copy(alpha = .96f))), RoundedCornerShape(22.dp)).border(1.dp, Color.White.copy(alpha = .09f), RoundedCornerShape(22.dp)).padding(16.dp), content = content)
}
@Composable private fun StatCard(label: String, value: String, accent: Color = Gold, modifier: Modifier = Modifier) {
    GlassCard(modifier) { Text(label, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(7.dp)); Text(value, color = accent, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
}

@Composable private fun HomePage(bookings: List<Booking>, dao: HjoDao, onBookings: () -> Unit) {
    val today = LocalDate.now().toString()
    var paidToday by remember { mutableLongStateOf(0L) }
    var paidMonth by remember { mutableLongStateOf(0L) }
    var outstanding by remember { mutableLongStateOf(0L) }
    LaunchedEffect(bookings) {
        val active = bookings.filter { it.status != "CANCELLED" }
        var todaySum = 0L; var monthSum = 0L; var balance = 0L
        active.forEach { b -> val p = dao.paid(b.id); balance += (b.totalPrice - p).coerceAtLeast(0); if (b.date == today) todaySum += p; if (b.date.startsWith(today.take(7))) monthSum += p }
        paidToday = todaySum; paidMonth = monthSum; outstanding = balance
    }
    val active = bookings.filter { it.status != "CANCELLED" }
    val todayItems = active.filter { it.date == today }
    val upcoming = active.count { it.date > today }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader("Welcome back", LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy")))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Today's bookings", todayItems.size.toString(), Purple, Modifier.weight(1f)); StatCard("Upcoming", upcoming.toString(), Gold, Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Completed", bookings.count { it.status == "COMPLETED" }.toString(), Gold, Modifier.weight(1f)); StatCard("Cancelled", bookings.count { it.status == "CANCELLED" }.toString(), Muted, Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Total bookings", bookings.size.toString(), Purple, Modifier.weight(1f)); StatCard("Today's collected", money(paidToday), Gold, Modifier.weight(1f))
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Monthly collected", money(paidMonth), Gold, Modifier.weight(1f)); StatCard("Outstanding", money(outstanding), Purple, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Today's schedule", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            TextButton(onClick = onBookings) { Text("View all", color = Gold) }
        }
        if (todayItems.isEmpty()) Text("No bookings scheduled for today.", color = Muted, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        todayItems.forEach { BookingTile(it, dao, {}, {}) }
        Spacer(Modifier.height(24.dp))
    }
}

private fun money(amount: Long) = "%s IQD".format("%,d".format(amount))
@Composable private fun BookingTile(b: Booking, dao: HjoDao, onEdit: () -> Unit, onWhatsApp: () -> Unit) {
    var paid by remember { mutableLongStateOf(0L) }
    var showPay by remember { mutableStateOf(false) }
    var payAmount by remember { mutableStateOf("") }
    var refund by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(b.id) { paid = dao.paid(b.id) }
    GlassCard(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(b.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${b.customerName}  •  ${b.phone}", color = Muted, fontSize = 12.sp)
                Text("${b.date}  •  ${time(b.startMinute)}–${time(b.endMinute)}", color = Gold, fontSize = 12.sp)
                Text("${b.resource}  •  ${b.status}", color = Muted, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(money(b.totalPrice), color = Gold, fontWeight = FontWeight.Bold)
                Text("Net paid ${money(paid)}", color = Muted, fontSize = 11.sp)
                Text("Due ${money(BookingRules.balance(b.totalPrice, paid))}", color = if (paid < b.totalPrice) Color(0xFFFF9D8F) else Color(0xFF72D6A4), fontSize = 11.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onEdit) { Text("Edit", color = Gold) }
            TextButton(onClick = { showPay = true }) { Text("Add payment", color = Purple) }
            TextButton(onClick = onWhatsApp) { Text("WhatsApp", color = Color(0xFF70D49B)) }
        }
    }
    if (showPay) AlertDialog(onDismissRequest = { showPay = false }, containerColor = Panel, title = { Text("Add payment", color = Color.White) }, text = {
        Column { OutlinedTextField(payAmount, { payAmount = it }, label = { Text("Amount (IQD)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(refund, { refund = it }); Text("Record as refund", color = Muted) } }
    }, confirmButton = { TextButton(onClick = { val amount = payAmount.toLongOrNull(); if (amount != null && amount > 0) scope.launch { dao.addPayment(Payment(bookingId = b.id, amount = if (refund) -amount else amount, note = if (refund) "Refund" else "Payment")); paid = dao.paid(b.id); showPay = false } }) { Text("Save", color = Gold) } }, dismissButton = { TextButton(onClick = { showPay = false }) { Text("Cancel") } })
}
private fun time(m: Int) = "%02d:%02d".format(m / 60, m % 60)

@Composable private fun BookingPage(bookings: List<Booking>, dao: HjoDao, onEdit: (Booking) -> Unit, onMessage: (Booking) -> Unit) {
    var filter by remember { mutableStateOf("ALL") }
    var query by remember { mutableStateOf("") }
    var calendarMode by remember { mutableStateOf("Daily") }
    var selectedDate by remember { mutableStateOf(LocalDate.now().toString()) }
    var calendarEnabled by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        PageHeader("Bookings", "Manage reservations, schedules and payments")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Calendar view", color = Color.White, fontWeight = FontWeight.SemiBold)
            Switch(checked = calendarEnabled, onCheckedChange = { calendarEnabled = it })
        }
        if (calendarEnabled) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Daily", "Weekly", "Monthly").forEach { mode -> FilterChip(calendarMode == mode, { calendarMode = mode }, label = { Text(mode) }) }
            }
            OutlinedTextField(selectedDate, { selectedDate = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), label = { Text("Choose date YYYY-MM-DD") }, singleLine = true)
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), placeholder = { Text("Search customer, phone or activity") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("ALL", "CONFIRMED", "COMPLETED", "CANCELLED").forEach { f -> FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f) }) }
        }
        val range = runCatching {
            val d = LocalDate.parse(selectedDate)
            when (calendarMode) {
                "Weekly" -> d.with(java.time.DayOfWeek.MONDAY).toString()..d.with(java.time.DayOfWeek.SUNDAY).toString()
                "Monthly" -> d.withDayOfMonth(1).toString()..d.withDayOfMonth(d.lengthOfMonth()).toString()
                else -> d.toString()..d.toString()
            }
        }.getOrNull()
        val filtered = bookings.filter { (filter == "ALL" || it.status == filter) && (!calendarEnabled || (range != null && it.date >= range.start && it.date <= range.endInclusive)) && (query.isBlank() || listOf(it.customerName, it.phone, it.title, it.resource).any { s -> s.contains(query, true) }) }
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp)) {
            if (filtered.isEmpty()) item { Text("No matching bookings.", color = Muted, modifier = Modifier.padding(24.dp)) }
            items(filtered, key = { it.id }) { b -> BookingTile(b, dao, { onEdit(b) }, { onMessage(b) }) }
        }
    }
}

@Composable private fun BookingDialog(existing: Booking?, onDismiss: () -> Unit, onSave: (Booking, Int, String) -> Unit) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var customer by remember { mutableStateOf(existing?.customerName ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var resource by remember { mutableStateOf(existing?.resource ?: "Court 1") }
    var date by remember { mutableStateOf(existing?.date ?: LocalDate.now().toString()) }
    var start by remember { mutableStateOf(existing?.let { time(it.startMinute) } ?: "09:00") }
    var end by remember { mutableStateOf(existing?.let { time(it.endMinute) } ?: "10:00") }
    var price by remember { mutableStateOf(existing?.totalPrice?.toString() ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    var status by remember { mutableStateOf(existing?.status ?: "CONFIRMED") }
    var frequency by remember { mutableStateOf("None") }
    var count by remember { mutableStateOf("1") }
    var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(if (existing == null) "New booking" else "Edit booking", color = Color.White) }, text = {
        Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Field(title, { title = it }, "Activity / service")
            Field(customer, { customer = it }, "Customer name")
            Field(phone, { phone = it }, "Phone number", KeyboardType.Phone)
            Field(resource, { resource = it }, "Resource / court")
            Field(date, { date = it }, "Date YYYY-MM-DD")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Field(start, { start = it }, "Start HH:mm", modifier = Modifier.weight(1f)); Field(end, { end = it }, "End HH:mm", modifier = Modifier.weight(1f)) }
            Field(price, { price = it }, "Total price (IQD)", KeyboardType.Number)
            Field(notes, { notes = it }, "Notes")
            if (existing != null) { Text("Status", color = Gold); Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("CONFIRMED", "COMPLETED", "CANCELLED").forEach { FilterChip(status == it, { status = it }, label = { Text(it) }) } } }
            if (existing == null) {
                Text("Repeat booking", color = Gold, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("None", "Daily", "Weekly", "Monthly", "Weekdays").forEach { FilterChip(frequency == it, { frequency = it }, label = { Text(it) }) } }
                if (frequency != "None") Field(count, { count = it }, "Occurrences (max 52)", KeyboardType.Number)
            }
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp)
        }
    }, confirmButton = { TextButton(onClick = {
        val s = runCatching { LocalTime.parse(start).toSecondOfDay() / 60 }.getOrNull(); val e = runCatching { LocalTime.parse(end).toSecondOfDay() / 60 }.getOrNull()
        val p = price.toLongOrNull()
        val validDate = runCatching { LocalDate.parse(date); true }.getOrDefault(false)
        if (title.isBlank() || customer.isBlank() || resource.isBlank() || !validDate || s == null || e == null || (s != null && e != null && !BookingRules.validInterval(s, e)) || p == null || p < 0) error = "Check required fields, date, time and price"
        else onSave(Booking(id = existing?.id ?: 0, title = title.trim(), customerName = customer.trim(), phone = phone.trim(), resource = resource.trim(), date = date, startMinute = s, endMinute = e, totalPrice = p, notes = notes, status = status), if (frequency == "None") 1 else count.toIntOrNull()?.coerceIn(1, 52) ?: 1, frequency)
    }) { Text("Save booking", color = Gold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
@Composable private fun Field(value: String, change: (String) -> Unit, label: String, keyboard: KeyboardType = KeyboardType.Text, modifier: Modifier = Modifier) {
    OutlinedTextField(value, change, modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = keyboard), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Muted.copy(alpha = .5f), focusedLabelColor = Gold, cursorColor = Gold))
}

@Composable private fun TournamentPage(items: List<Tournament>, dao: HjoDao) {
    Column(Modifier.fillMaxSize()) {
        PageHeader("Tournaments", "Create events and track competition formats")
        if (items.isEmpty()) Text("No tournaments yet. Tap + to create your first event.", color = Muted, modifier = Modifier.padding(20.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 80.dp)) {
            items(items, key = { it.id }) { t ->
                var participants by remember(t.id) { mutableStateOf(t.participants) }
                GlassCard(Modifier.padding(horizontal = 16.dp, vertical = 7.dp)) {
                    Text(t.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("${t.format}  •  ${t.startDate} – ${t.endDate}", color = Gold, fontSize = 12.sp)
                    Text("Participants: ${t.participants.split('\n').filter { it.isNotBlank() }.size}  •  ${t.status}", color = Muted, fontSize = 12.sp)
                    var showMatches by remember { mutableStateOf(false) }
                    TextButton(onClick = { showMatches = !showMatches }) { Text(if (showMatches) "Hide matches" else "Manage matches", color = Purple) }
                    if (showMatches) MatchManager(t, dao)
                }
            }
        }
    }
}
@Composable private fun TournamentDialog(onDismiss: () -> Unit, onSave: (Tournament) -> Unit) {
    var name by remember { mutableStateOf("") }; var format by remember { mutableStateOf("Knockout") }; var start by remember { mutableStateOf(LocalDate.now().toString()) }; var end by remember { mutableStateOf(LocalDate.now().plusDays(1).toString()) }; var people by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text("New tournament", color = Color.White) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(name, { name = it }, "Tournament name")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("Knockout", "League", "Groups + knockout").forEach { FilterChip(format == it, { format = it }, label = { Text(it, fontSize = 10.sp) }) } }
            Field(start, { start = it }, "Start date YYYY-MM-DD"); Field(end, { end = it }, "End date YYYY-MM-DD")
            OutlinedTextField(people, { people = it }, label = { Text("Participants (one per line)") }, minLines = 3)
        }
    }, confirmButton = { TextButton(onClick = { if (name.isNotBlank() && runCatching { LocalDate.parse(start); LocalDate.parse(end); true }.getOrDefault(false) && end >= start) onSave(Tournament(name = name, format = format, startDate = start, endDate = end, participants = people)) }) { Text("Create", color = Gold) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
@Composable private fun MatchManager(t: Tournament, dao: HjoDao) {
    val matches by dao.matches(t.id).collectAsState(initial = emptyList())
    var a by remember { mutableStateOf("") }; var b by remember { mutableStateOf("") }; var round by remember { mutableStateOf("Round 1") }
    val scope = rememberCoroutineScope()
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        matches.forEach { m ->
            var scoreA by remember(m.id, m.scoreA) { mutableStateOf(m.scoreA?.toString() ?: "") }
            var scoreB by remember(m.id, m.scoreB) { mutableStateOf(m.scoreB?.toString() ?: "") }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("${m.roundName}: ${m.playerA} vs ${m.playerB}", color = Color.White, fontSize = 12.sp); Text(if (m.played) "Result saved" else "Pending", color = Muted, fontSize = 10.sp) }
                OutlinedTextField(scoreA, { scoreA = it }, Modifier.width(54.dp), singleLine = true, label = { Text("A") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text(" : ", color = Gold)
                OutlinedTextField(scoreB, { scoreB = it }, Modifier.width(54.dp), singleLine = true, label = { Text("B") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                TextButton(onClick = { val sa = scoreA.toIntOrNull(); val sb = scoreB.toIntOrNull(); if (sa != null && sb != null && sa >= 0 && sb >= 0) scope.launch { dao.updateMatch(m.copy(scoreA = sa, scoreB = sb, played = true)) } }) { Text("Save", color = Gold) }
            }
        }
        val standings = matches.filter { it.played }.flatMap { listOf(it.playerA, it.playerB) }.distinct().map { player ->
            val played = matches.filter { it.played && (it.playerA == player || it.playerB == player) }
            val wins = played.count { (it.playerA == player && (it.scoreA ?: 0) > (it.scoreB ?: 0)) || (it.playerB == player && (it.scoreB ?: 0) > (it.scoreA ?: 0)) }
            val draws = played.count { it.scoreA == it.scoreB }
            Triple(player, wins * 3 + draws, played.size)
        }.sortedByDescending { it.second }
        if (standings.isNotEmpty()) {
            Text("Standings", color = Gold, fontWeight = FontWeight.Bold)
            standings.forEachIndexed { index, row -> Text("${index + 1}. ${row.first}  •  ${row.second} pts  •  ${row.third} played", color = Muted, fontSize = 12.sp) }
        }
        Divider(color = Muted.copy(alpha = .3f))
        Field(round, { round = it }, "Round"); Field(a, { a = it }, "Player A"); Field(b, { b = it }, "Player B")
        Button(onClick = { if (a.isNotBlank() && b.isNotBlank() && a != b) scope.launch { dao.addMatch(TournamentMatch(tournamentId = t.id, roundName = round, playerA = a, playerB = b)); a = ""; b = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Add match") }
    }
}

@Composable private fun SettingsPage(onExport: () -> Unit, onImport: () -> Unit) {
    val context = LocalContext.current
    var reminders by remember { mutableStateOf(context.getSharedPreferences("hjoozati_settings", 0).getBoolean("reminders_enabled", true)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader("Settings", "Local app preferences and data tools")
        GlassCard(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("Data & backup", color = Gold, fontWeight = FontWeight.Bold)
            Text("Your data is stored locally on this device. Export a JSON backup and keep it somewhere safe.", color = Muted, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text("Booking reminders", color = Color.White); Text("Local notification one day before", color = Muted, fontSize = 11.sp) }; Switch(checked = reminders, onCheckedChange = { reminders = it; context.getSharedPreferences("hjoozati_settings", 0).edit().putBoolean("reminders_enabled", it).apply() }) }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onExport, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Export backup") }
            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Restore backup") }
        }
        GlassCard(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("About HJOOZATI", color = Gold, fontWeight = FontWeight.Bold)
            Text("Version 2.0.0\nBooking and tournament management\nPurple • Gold • Black", color = Muted, fontSize = 13.sp)
        }
    }
}
