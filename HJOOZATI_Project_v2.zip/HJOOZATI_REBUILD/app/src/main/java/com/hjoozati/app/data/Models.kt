package com.hjoozati.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "bookings", indices = [Index(value = ["date", "resource", "status"])])
data class Booking(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val customerName: String,
    val phone: String,
    val resource: String,
    val date: String,
    val startMinute: Int,
    val endMinute: Int,
    val totalPrice: Long,
    val notes: String = "",
    val status: String = "CONFIRMED",
    val recurrenceGroup: String = ""
)

@Entity(tableName = "payments", foreignKeys = [ForeignKey(entity = Booking::class, parentColumns = ["id"], childColumns = ["bookingId"], onDelete = ForeignKey.CASCADE)], indices = [Index("bookingId")])
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookingId: Long,
    val amount: Long,
    val paidAt: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "tournaments")
data class Tournament(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val format: String,
    val startDate: String,
    val endDate: String,
    val participants: String = "",
    val status: String = "PLANNED"
)

@Entity(tableName = "matches", foreignKeys = [ForeignKey(entity = Tournament::class, parentColumns = ["id"], childColumns = ["tournamentId"], onDelete = ForeignKey.CASCADE)], indices = [Index("tournamentId")])
data class TournamentMatch(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tournamentId: Long,
    val roundName: String,
    val playerA: String,
    val playerB: String,
    val scoreA: Int? = null,
    val scoreB: Int? = null,
    val played: Boolean = false
)

@Dao interface HjoDao {
    @Query("SELECT * FROM bookings ORDER BY date, startMinute") fun bookings(): Flow<List<Booking>>
    @Query("SELECT * FROM bookings WHERE date = :date AND status != 'CANCELLED' ORDER BY startMinute") suspend fun activeOn(date: String): List<Booking>
    @Query("SELECT * FROM bookings WHERE id = :id") suspend fun booking(id: Long): Booking?
    @Insert suspend fun addBooking(item: Booking): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreBookings(items: List<Booking>)
    @Update suspend fun updateBooking(item: Booking)
    @Query("UPDATE bookings SET status='CANCELLED' WHERE id=:id") suspend fun cancelBooking(id: Long)
    @Query("SELECT * FROM payments WHERE bookingId=:bookingId ORDER BY paidAt") suspend fun payments(bookingId: Long): List<Payment>
    @Query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE bookingId=:bookingId") suspend fun paid(bookingId: Long): Long
    @Insert suspend fun addPayment(item: Payment): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restorePayments(items: List<Payment>)
    @Query("SELECT * FROM tournaments ORDER BY startDate DESC") fun tournaments(): Flow<List<Tournament>>
    @Insert suspend fun addTournament(item: Tournament): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreTournaments(items: List<Tournament>)
    @Update suspend fun updateTournament(item: Tournament)
    @Query("SELECT * FROM matches WHERE tournamentId=:id ORDER BY id") fun matches(id: Long): Flow<List<TournamentMatch>>
    @Insert suspend fun addMatch(item: TournamentMatch): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restoreMatches(items: List<TournamentMatch>)
    @Update suspend fun updateMatch(item: TournamentMatch)
    @Query("SELECT * FROM bookings") suspend fun allBookings(): List<Booking>
    @Query("SELECT * FROM payments") suspend fun allPayments(): List<Payment>
    @Query("SELECT * FROM tournaments") suspend fun allTournaments(): List<Tournament>
    @Query("SELECT * FROM matches") suspend fun allMatches(): List<TournamentMatch>
    @Query("DELETE FROM matches") suspend fun clearMatches()
    @Query("DELETE FROM tournaments") suspend fun clearTournaments()
    @Query("DELETE FROM payments") suspend fun clearPayments()
    @Query("DELETE FROM bookings") suspend fun clearBookings()
    @Transaction
    suspend fun replaceAll(bookings: List<Booking>, payments: List<Payment>, tournaments: List<Tournament>, matches: List<TournamentMatch>) {
        clearMatches(); clearTournaments(); clearPayments(); clearBookings()
        restoreBookings(bookings); restorePayments(payments); restoreTournaments(tournaments); restoreMatches(matches)
    }
}

@Database(entities = [Booking::class, Payment::class, Tournament::class, TournamentMatch::class], version = 1, exportSchema = true)
abstract class HjoDatabase : RoomDatabase() {
    abstract fun dao(): HjoDao
    companion object {
        @Volatile private var INSTANCE: HjoDatabase? = null
        fun get(context: android.content.Context): HjoDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, HjoDatabase::class.java, "hjoozati_local.db").build().also { INSTANCE = it }
        }
    }
}
