package com.hjoozati.app.util

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import com.hjoozati.app.R

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Upcoming booking"
        val detail = intent.getStringExtra("detail") ?: "You have a booking coming up."
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("booking_reminders", "Booking reminders", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = NotificationCompat.Builder(context, "booking_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(detail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail)).setAutoCancel(true).build()
        manager.notify(intent.getIntExtra("notificationId", 1), notification)
    }
}

object ReminderScheduler {
    fun schedule(context: Context, bookingId: Long, title: String, date: String, startMinute: Int) {
        val prefs = context.getSharedPreferences("hjoozati_settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", true)) return
        val day = java.time.LocalDate.parse(date).minusDays(1)
        val at = day.atTime(9, 0).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (at <= System.currentTimeMillis()) return
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", "Booking tomorrow: $title")
            putExtra("detail", "Your booking is scheduled for $date at %02d:%02d".format(startMinute / 60, startMinute % 60))
            putExtra("notificationId", bookingId.toInt())
        }
        val pending = PendingIntent.getBroadcast(context, bookingId.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
    }
}
