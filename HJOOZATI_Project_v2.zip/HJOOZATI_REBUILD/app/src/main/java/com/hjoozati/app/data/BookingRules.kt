package com.hjoozati.app.data

object BookingRules {
    fun overlaps(startA: Int, endA: Int, startB: Int, endB: Int): Boolean = startA < endB && endA > startB
    fun validInterval(start: Int, end: Int): Boolean = start in 0..1439 && end in 1..1440 && end > start
    fun balance(total: Long, netPaid: Long): Long = (total - netPaid).coerceAtLeast(0L)
}
