# HJOOZATI — Android rebuild

A separate rebuild based on the latest approved HJOOZATI brief. The original repository/project is not modified by this source package.

## Stack
- Kotlin, Android SDK, Jetpack Compose + Material 3
- Room local persistence (bookings, payments, tournaments, matches)
- Local Android notifications via AlarmManager/BroadcastReceiver
- JSON backup and restore through Android's Storage Access Framework

## Build
Requires JDK 17, Android SDK 34 and Gradle 8.0.2.

```bash
gradle testDebugUnitTest
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/android.yml`; after pushing this project to a new repository, run the workflow and download the `HJOOZATI-debug-apk` artifact.

## Implemented in this source
- Purple/gold/black dark glass-style interface; Home, Bookings, Tournaments, Settings navigation
- Local booking persistence; create/edit/status update; customer and resource details; search and status filters
- Same-resource time-overlap prevention, including repeated occurrences; cancelled reservations are excluded
- Daily/weekly/monthly calendar filtering and date selection
- Multiple payments per booking, net paid and outstanding balances; refunds represented as negative payment entries
- Daily, weekly, monthly and weekday recurrence by occurrence count (up to 52)
- Local reminder toggle and a one-day-before reminder at 9:00 AM
- Tournament creation, formats, match creation, score entry and basic league standings
- Manual WhatsApp handoff with a prefilled message; the user must press Send in WhatsApp
- Local JSON backup/restore with structural/version validation and database transaction

## Known work remaining before production release
- The approved Freedom Tower logo image was not present in the supplied ZIP; the app currently uses a text wordmark. Add the exact approved asset when supplied.
- Recurrence currently supports daily, weekly, monthly and Monday–Friday patterns by count. Custom weekday selection and an explicit repeat-until date still need UI support.
- Tournament match scheduling/bracket generation and automatic knockout progression are not included yet; matches/results can be entered manually and basic standings are calculated from results.
- Reminder configuration currently provides an enable/disable switch and a fixed reminder time (09:00 the day before); per-event reminder offsets are not exposed.
- This package has not been built or run on an Android SDK in this workspace. Use the included GitHub Actions workflow or Android Studio to verify the APK before distribution.

## Scope exclusions retained
No cloud/server sync, customer CRM, waiting list, expenses/profit module, PDF reports, analytics dashboard, AI assistant, biometric lock, automatic WhatsApp delivery/API, ads or subscriptions.
